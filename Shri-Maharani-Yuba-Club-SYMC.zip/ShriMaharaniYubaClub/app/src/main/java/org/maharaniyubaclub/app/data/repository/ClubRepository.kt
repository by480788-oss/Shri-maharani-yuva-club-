package org.maharaniyubaclub.app.data.repository

import android.net.Uri
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import org.maharaniyubaclub.app.FirestoreProvider
import org.maharaniyubaclub.app.data.model.*
import java.util.UUID

class ClubRepository(
    private val db: FirebaseFirestore = FirestoreProvider.db,
    private val storage: FirebaseStorage = FirebaseStorage.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    fun observeClubSettings(): Flow<ClubSettings> = callbackFlow {
        val reg = db.collection("club_settings").document("main")
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObject(ClubSettings::class.java) ?: ClubSettings())
            }
        awaitClose { reg.remove() }
    }

    fun observeAnnouncements(): Flow<List<AnnouncementItem>> = callbackFlow {
        val reg = db.collection("announcements")
            .orderBy("publishedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(AnnouncementItem::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    suspend fun markAnnouncementRead(announcementId: String) {
        val uid = auth.currentUser?.uid ?: return
        db.collection("announcements").document(announcementId)
            .update("readByUids", FieldValue.arrayUnion(uid)).await()
    }

    fun observeEvents(): Flow<List<ClubEvent>> = callbackFlow {
        val reg = db.collection("events")
            .orderBy("eventTimestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(ClubEvent::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeActivities(): Flow<List<ClubActivity>> = callbackFlow {
        val reg = db.collection("activities")
            .orderBy("activityDate", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(ClubActivity::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeCommittee(): Flow<List<CommitteeMember>> = callbackFlow {
        val reg = db.collection("committee")
            .orderBy("orderIndex", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(CommitteeMember::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeGallery(): Flow<List<GalleryItem>> = callbackFlow {
        val reg = db.collection("gallery")
            .orderBy("uploadedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(GalleryItem::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeMyDonations(uid: String): Flow<List<DonationRecord>> = callbackFlow {
        val reg = db.collection("donations")
            .whereEqualTo("memberUid", uid)
            .orderBy("submittedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(DonationRecord::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeFundTransactions(): Flow<List<FundTransaction>> = callbackFlow {
        val reg = db.collection("fund_transactions")
            .orderBy("transactionDate", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(FundTransaction::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    suspend fun submitDonation(
        profile: MemberProfile,
        amount: Double,
        referenceNumber: String,
        proofUri: Uri?
    ) {
        val proofUrl = if (proofUri != null) {
            val ref = storage.reference.child("donation_proofs/${profile.uid}/${UUID.randomUUID()}.jpg")
            ref.putFile(proofUri).await()
            ref.downloadUrl.await().toString()
        } else ""

        val doc = db.collection("donations").document()
        doc.set(
            mapOf(
                "id" to doc.id,
                "memberUid" to profile.uid,
                "memberName" to profile.fullName,
                "memberCode" to profile.memberCode,
                "amount" to amount,
                "currency" to "NPR",
                "referenceNumber" to referenceNumber.trim(),
                "proofUrl" to proofUrl,
                "status" to "PENDING",
                "adminNote" to "",
                "submittedAt" to Timestamp.now()
            )
        ).await()
    }

    suspend fun updateMyProfile(
        uid: String,
        fullName: String,
        address: String,
        showPhone: Boolean,
        showEmail: Boolean,
        avatarUri: Uri?
    ) {
        val updates = mutableMapOf<String, Any>(
            "fullName" to fullName.trim(),
            "address" to address.trim(),
            "privacyShowPhone" to showPhone,
            "privacyShowEmail" to showEmail,
            "updatedAt" to Timestamp.now()
        )
        if (avatarUri != null) {
            val ref = storage.reference.child("member_avatars/$uid/avatar.jpg")
            ref.putFile(avatarUri).await()
            updates["photoUrl"] = ref.downloadUrl.await().toString()
        }
        db.collection("members").document(uid).update(updates).await()
    }

    suspend fun sendSupportInquiry(subject: String, message: String) {
        val uid = auth.currentUser?.uid ?: error("Sign in required.")
        db.collection("notification_records").add(
            mapOf(
                "titleEn" to "Support: ${subject.trim()}",
                "titleNe" to "सहयोग: ${subject.trim()}",
                "bodyEn" to message.trim(),
                "bodyNe" to message.trim(),
                "status" to "SUPPORT_TICKET",
                "sentCount" to 0,
                "failureCount" to 0,
                "createdAt" to Timestamp.now(),
                "createdByUid" to uid
            )
        ).await()
    }
}
