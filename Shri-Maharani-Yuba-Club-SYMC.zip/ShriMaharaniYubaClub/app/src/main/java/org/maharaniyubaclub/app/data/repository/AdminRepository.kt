package org.maharaniyubaclub.app.data.repository

import android.net.Uri
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import org.maharaniyubaclub.app.FirestoreProvider
import org.maharaniyubaclub.app.data.model.*
import java.util.UUID

class AdminRepository(
    private val db: FirebaseFirestore = FirestoreProvider.db,
    private val storage: FirebaseStorage = FirebaseStorage.getInstance(),
    private val functions: FirebaseFunctions = FirebaseFunctions.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private suspend fun log(action: String, collection: String, targetId: String, details: String) {
        val user = auth.currentUser ?: return
        db.collection("admin_activity_logs").add(
            mapOf(
                "adminUid" to user.uid,
                "adminEmail" to (user.email ?: ""),
                "action" to action,
                "targetCollection" to collection,
                "targetId" to targetId,
                "details" to details,
                "timestamp" to Timestamp.now()
            )
        ).await()
    }

    fun observeAllMembers(): Flow<List<MemberProfile>> = callbackFlow {
        val reg = db.collection("members").orderBy("joinedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(MemberProfile::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeAllDonations(): Flow<List<DonationRecord>> = callbackFlow {
        val reg = db.collection("donations").orderBy("submittedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(DonationRecord::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeAdmins(): Flow<List<AdminRecord>> = callbackFlow {
        val reg = db.collection("admins").addSnapshotListener { snap, _ ->
            trySend(snap?.toObjects(AdminRecord::class.java) ?: emptyList())
        }
        awaitClose { reg.remove() }
    }

    fun observeActivityLogs(): Flow<List<AdminActivityLog>> = callbackFlow {
        val reg = db.collection("admin_activity_logs")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.toObjects(AdminActivityLog::class.java) ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    suspend fun updateMemberStatus(memberUid: String, approvalStatus: String, activeStatus: String) {
        functions.getHttpsCallable("adminUpdateMemberStatus").call(
            mapOf("memberUid" to memberUid, "approvalStatus" to approvalStatus, "activeStatus" to activeStatus)
        ).await()
    }

    suspend fun createMember(fullName: String, email: String, phoneE164: String, countryCode: String, password: String) {
        functions.getHttpsCallable("adminCreateMember").call(
            mapOf(
                "fullName" to fullName,
                "email" to email,
                "phoneE164" to phoneE164,
                "countryCode" to countryCode,
                "password" to password
            )
        ).await()
    }

    suspend fun updateMemberDetails(member: MemberProfile) {
        db.collection("members").document(member.uid).update(
            mapOf(
                "fullName" to member.fullName.trim(),
                "address" to member.address.trim(),
                "updatedAt" to Timestamp.now()
            )
        ).await()
        log("EDIT_MEMBER", "members", member.uid, member.fullName)
    }

    suspend fun publishAnnouncement(type: String, titleEn: String, titleNe: String, bodyEn: String, bodyNe: String, sendPush: Boolean): String {
        val res = functions.getHttpsCallable("publishAnnouncementAndNotify").call(
            mapOf(
                "type" to type,
                "titleEn" to titleEn,
                "titleNe" to titleNe,
                "bodyEn" to bodyEn,
                "bodyNe" to bodyNe,
                "sendPush" to sendPush
            )
        ).await()
        val data = res.data as Map<*, *>
        return "Status: ${data["status"]} (Sent: ${data["sentCount"]}, Failed: ${data["failureCount"]})"
    }

    suspend fun deleteAnnouncement(id: String) {
        db.collection("announcements").document(id).delete().await()
        log("DELETE_ANNOUNCEMENT", "announcements", id, "")
    }

    suspend fun saveEvent(event: ClubEvent, newPhotoUri: Uri?) {
        val doc = if (event.id.isBlank()) db.collection("events").document() else db.collection("events").document(event.id)
        val urls = event.photoUrls.toMutableList()
        if (newPhotoUri != null) {
            val ref = storage.reference.child("events/${doc.id}/${UUID.randomUUID()}.jpg")
            ref.putFile(newPhotoUri).await()
            urls.add(ref.downloadUrl.await().toString())
        }
        val payload = event.copy(
            id = doc.id,
            photoUrls = urls,
            eventTimestamp = event.eventTimestamp ?: Timestamp.now()
        )
        doc.set(payload).await()
        log("SAVE_EVENT", "events", doc.id, event.titleEn)
    }

    suspend fun deleteEvent(id: String) {
        db.collection("events").document(id).delete().await()
        log("DELETE_EVENT", "events", id, "")
    }

    suspend fun saveActivity(activity: ClubActivity, photoUri: Uri?) {
        val doc = if (activity.id.isBlank()) db.collection("activities").document() else db.collection("activities").document(activity.id)
        var url = activity.photoUrl
        if (photoUri != null) {
            val ref = storage.reference.child("events/activity_${doc.id}.jpg")
            ref.putFile(photoUri).await()
            url = ref.downloadUrl.await().toString()
        }
        doc.set(activity.copy(id = doc.id, photoUrl = url, activityDate = activity.activityDate ?: Timestamp.now())).await()
        log("SAVE_ACTIVITY", "activities", doc.id, activity.titleEn)
    }

    suspend fun deleteActivity(id: String) {
        db.collection("activities").document(id).delete().await()
        log("DELETE_ACTIVITY", "activities", id, "")
    }

    suspend fun saveCommitteeMember(member: CommitteeMember, photoUri: Uri?) {
        val doc = if (member.id.isBlank()) db.collection("committee").document() else db.collection("committee").document(member.id)
        var url = member.photoUrl
        if (photoUri != null) {
            val ref = storage.reference.child("committee/${doc.id}.jpg")
            ref.putFile(photoUri).await()
            url = ref.downloadUrl.await().toString()
        }
        doc.set(member.copy(id = doc.id, photoUrl = url)).await()
        log("SAVE_COMMITTEE", "committee", doc.id, member.name)
    }

    suspend fun deleteCommitteeMember(id: String) {
        db.collection("committee").document(id).delete().await()
        log("DELETE_COMMITTEE", "committee", id, "")
    }

    suspend fun uploadGalleryMedia(albumName: String, mediaType: String, captionEn: String, captionNe: String, fileUri: Uri) {
        val doc = db.collection("gallery").document()
        val ext = if (mediaType == "VIDEO") "mp4" else "jpg"
        val ref = storage.reference.child("gallery/${doc.id}.$ext")
        ref.putFile(fileUri).await()
        val url = ref.downloadUrl.await().toString()
        doc.set(GalleryItem(doc.id, albumName, mediaType, url, captionEn, captionNe, Timestamp.now())).await()
        log("UPLOAD_MEDIA", "gallery", doc.id, "$mediaType in $albumName")
    }

    suspend fun updateGalleryCaption(id: String, captionEn: String, captionNe: String) {
        db.collection("gallery").document(id).update(mapOf("captionEn" to captionEn, "captionNe" to captionNe)).await()
        log("EDIT_MEDIA", "gallery", id, captionEn)
    }

    suspend fun deleteGalleryItem(id: String) {
        db.collection("gallery").document(id).delete().await()
        log("DELETE_MEDIA", "gallery", id, "")
    }

    suspend fun uploadDonationQr(uri: Uri) {
        val ref = storage.reference.child("donation_qr/official_qr.jpg")
        ref.putFile(uri).await()
        val url = ref.downloadUrl.await().toString()
        db.collection("club_settings").document("main").set(mapOf("donationQrUrl" to url), SetOptions.merge()).await()
        log("UPLOAD_QR", "club_settings", "main", "Updated donation QR")
    }

    suspend fun removeDonationQr() {
        try { storage.reference.child("donation_qr/official_qr.jpg").delete().await() } catch (_: Exception) {}
        db.collection("club_settings").document("main").set(mapOf("donationQrUrl" to ""), SetOptions.merge()).await()
        log("REMOVE_QR", "club_settings", "main", "Removed donation QR")
    }

    suspend fun uploadOfficialLogo(uri: Uri) {
        val ref = storage.reference.child("public_branding/official_logo.png")
        ref.putFile(uri).await()
        val url = ref.downloadUrl.await().toString()
        db.collection("club_settings").document("main").set(mapOf("officialLogoUrl" to url), SetOptions.merge()).await()
        log("UPLOAD_LOGO", "club_settings", "main", "Updated official logo")
    }

    suspend fun verifyDonation(donationId: String, decision: String, adminNote: String) {
        functions.getHttpsCallable("adminVerifyDonation").call(
            mapOf("donationId" to donationId, "decision" to decision, "adminNote" to adminNote)
        ).await()
    }

    suspend fun addFundTransaction(type: String, category: String, amount: Double, descEn: String, descNe: String) {
        val uid = auth.currentUser?.uid ?: error("Not signed in.")
        val doc = db.collection("fund_transactions").document()
        doc.set(
            FundTransaction(
                id = doc.id,
                type = type,
                category = category,
                amount = amount,
                descriptionEn = descEn,
                descriptionNe = descNe,
                linkedDonationId = "",
                recordedByUid = uid,
                transactionDate = Timestamp.now()
            )
        ).await()
        log("ADD_TRANSACTION_$type", "fund_transactions", doc.id, "$category: $amount")
    }

    suspend fun saveClubSettings(settings: ClubSettings) {
        db.collection("club_settings").document("main").set(settings, SetOptions.merge()).await()
        log("UPDATE_SETTINGS", "club_settings", "main", "Updated club settings/content")
    }

    suspend fun setAdminRole(email: String, grant: Boolean) {
        functions.getHttpsCallable("setAdminRole").call(mapOf("email" to email.trim().lowercase(), "grant" to grant)).await()
    }
}
