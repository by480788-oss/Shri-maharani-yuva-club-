package org.maharaniyubaclub.app.ui.screens.member

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.data.model.ClubSettings
import org.maharaniyubaclub.app.data.model.UserSession
import org.maharaniyubaclub.app.ui.components.*
import org.maharaniyubaclub.app.ui.theme.DeepOrange
import org.maharaniyubaclub.app.ui.theme.RoyalMaroon

private data class DashTile(val route: String, val labelRes: Int, val icon: ImageVector, val requiresApproved: Boolean = true)

@Composable
fun MemberDashboardScreen(
    currentLang: String,
    session: UserSession,
    settings: ClubSettings,
    onChangeLanguage: (String) -> Unit,
    onNavigate: (String) -> Unit,
    onOpenAdmin: () -> Unit,
    onLogout: () -> Unit
) {
    val profile = session.memberProfile
    val isApprovedActive = (profile?.approvalStatus == "APPROVED" && profile.activeStatus == "ACTIVE") || session.isAdmin

    val tiles = listOf(
        DashTile("profile", R.string.profile, Icons.Default.Person, false),
        DashTile("announcements", R.string.announcements, Icons.Default.Campaign),
        DashTile("news", R.string.news_updates, Icons.Default.Newspaper),
        DashTile("events_upcoming", R.string.upcoming_events, Icons.Default.Event),
        DashTile("events_past", R.string.past_events, Icons.Default.History),
        DashTile("activities", R.string.club_activities, Icons.Default.Groups),
        DashTile("committee", R.string.committee, Icons.Default.Badge),
        DashTile("gallery_photo", R.string.photo_gallery, Icons.Default.PhotoLibrary),
        DashTile("gallery_video", R.string.video_gallery, Icons.Default.VideoLibrary),
        DashTile("donation", R.string.donation_support, Icons.Default.VolunteerActivism),
        DashTile("fund_summary", R.string.fund_summary, Icons.Default.AccountBalanceWallet),
        DashTile("contact", R.string.contact_us, Icons.Default.Call, false),
        DashTile("about", R.string.about_club, Icons.Default.Info, false),
        DashTile("terms", R.string.terms_conditions, Icons.Default.Gavel, false),
        DashTile("privacy", R.string.privacy_policy, Icons.Default.PrivacyTip, false),
        DashTile("help", R.string.help_support, Icons.Default.SupportAgent, false),
        DashTile("settings", R.string.settings, Icons.Default.Settings, false)
    )

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = stringResource(R.string.member_dashboard),
                actions = {
                    if (session.isAdmin) {
                        TextButton(onClick = onOpenAdmin) {
                            Text("ADMIN", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                    IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, stringResource(R.string.logout)) }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            RoyalHeaderBanner(
                logoUrl = settings.officialLogoUrl,
                title = "${stringResource(R.string.welcome_title)}: ${profile?.fullName ?: ""}",
                subtitle = "${stringResource(R.string.member_id)}: ${profile?.memberCode?.ifBlank { "Pending" } ?: "N/A"} • ${profile?.approvalStatus ?: "N/A"}/${profile?.activeStatus ?: "N/A"}"
            )

            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.language), fontWeight = FontWeight.SemiBold)
                LanguageToggleRow(currentLang, onChangeLanguage)
            }

            if (!isApprovedActive) {
                RoyalCard(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(
                        text = if (profile?.approvalStatus == "PENDING") stringResource(R.string.pending_approval_banner)
                        else stringResource(R.string.inactive_banner),
                        color = RoyalMaroon
                    )
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(tiles) { tile ->
                    val enabled = !tile.requiresApproved || isApprovedActive
                    RoyalCard(
                        modifier = Modifier.clickable(enabled = enabled) { onNavigate(tile.route) }
                    ) {
                        Icon(
                            tile.icon,
                            contentDescription = null,
                            tint = if (enabled) DeepOrange else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(30.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            stringResource(tile.labelRes),
                            fontWeight = FontWeight.SemiBold,
                            color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }
        }
    }
}
