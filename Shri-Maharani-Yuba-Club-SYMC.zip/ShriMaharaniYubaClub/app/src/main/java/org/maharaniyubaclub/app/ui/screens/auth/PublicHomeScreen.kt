package org.maharaniyubaclub.app.ui.screens.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.data.model.ClubSettings
import org.maharaniyubaclub.app.ui.components.*
import org.maharaniyubaclub.app.ui.theme.DeepOrange

@Composable
fun PublicHomeScreen(
    currentLang: String,
    settings: ClubSettings,
    onChangeLanguage: (String) -> Unit,
    onLoginClick: () -> Unit,
    onRegisterClick: () -> Unit,
    onAboutClick: () -> Unit,
    onContactClick: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        RoyalHeaderBanner(
            logoUrl = settings.officialLogoUrl,
            title = stringResource(R.string.app_name),
            subtitle = stringResource(R.string.royal_motto)
        )

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.language), style = MaterialTheme.typography.titleMedium)
                LanguageToggleRow(currentLang, onChangeLanguage)
            }

            RoyalCard {
                Text(stringResource(R.string.welcome_title), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.public_notice), style = MaterialTheme.typography.bodyMedium)
            }

            Button(
                onClick = onLoginClick,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = DeepOrange)
            ) {
                Icon(Icons.Default.Login, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.login))
            }

            OutlinedButton(
                onClick = onRegisterClick,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Default.PersonAdd, null)
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.create_account))
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onAboutClick, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Info, null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.about_club))
                }
                OutlinedButton(onClick = onContactClick, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Call, null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.contact_us))
                }
            }
        }
    }
}
