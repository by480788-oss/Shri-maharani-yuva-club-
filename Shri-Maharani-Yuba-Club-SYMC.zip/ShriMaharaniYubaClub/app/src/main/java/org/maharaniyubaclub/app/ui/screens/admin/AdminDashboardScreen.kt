package org.maharaniyubaclub.app.ui.screens.admin

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.data.model.UserSession
import org.maharaniyubaclub.app.ui.components.LanguageToggleRow
import org.maharaniyubaclub.app.ui.components.RoyalCard
import org.maharaniyubaclub.app.ui.components.RoyalTopBar
import org.maharaniyubaclub.app.ui.theme.DeepOrange
import org.maharaniyubaclub.app.ui.viewmodel.AdminViewModel
import org.maharaniyubaclub.app.ui.viewmodel.MemberViewModel

private data class AdminModule(val route: String, val labelRes: Int, val badge: String, val icon: ImageVector)

@Composable
fun AdminDashboardScreen(
    currentLang: String,
    session: UserSession,
    adminVm: AdminViewModel,
    memberVm: MemberViewModel,
    onChangeLanguage: (String) -> Unit,
    onNavigate: (String) -> Unit,
    onMemberView: () -> Unit,
    onLogout: () -> Unit
) {
    if (!session.isAdmin && !session.isSuperAdmin) {
        Box(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Unauthorized: Admin access required.")
        }
        return
    }

    val members by adminVm.members.collectAsState()
    val donations by adminVm.donations.collectAsState()
    val summary by memberVm.fundSummary.collectAsState()

    val pendingCount = members.count { it.approvalStatus == "PENDING" }
    val approvedCount = members.count { it.approvalStatus == "APPROVED" }
    val rejectedCount = members.count { it.approvalStatus == "REJECTED" }
    val activeCount = members.count { it.activeStatus == "ACTIVE" }
    val inactiveCount = members.count { it.activeStatus == "INACTIVE" }
    val pendingDonations = donations.count { it.status == "PENDING" }

    val modules = buildList {
        add(AdminModule("admin_members", R.string.admin_members, "$approvedCount/${members.size}", Icons.Default.People))
        add(AdminModule("admin_donations", R.string.admin_donations, "$pendingDonations pending", Icons.Default.QrCode2))
        add(AdminModule("admin_funds", R.string.admin_funds, "Bal: ${summary.currentBalance}", Icons.Default.AccountBalance))
        add(AdminModule("admin_announcements", R.string.admin_announcements, "", Icons.Default.Campaign))
        add(AdminModule("admin_events", R.string.admin_events, "", Icons.Default.Event))
        add(AdminModule("admin_committee", R.string.admin_committee, "", Icons.Default.Badge))
        add(AdminModule("admin_gallery", R.string.admin_gallery, "", Icons.Default.Collections))
        add(AdminModule("admin_settings", R.string.admin_settings, "", Icons.Default.Settings))
        add(AdminModule("admin_logs", R.string.admin_logs, "", Icons.Default.HistoryEdu))
        if (session.isSuperAdmin) add(AdminModule("admin_roles", R.string.admin_roles, "", Icons.Default.AdminPanelSettings))
    }

    Scaffold(
        topBar = {
            RoyalTopBar(
                title = stringResource(R.string.admin_dashboard),
                actions = {
                    TextButton(onClick = onMemberView) { Text("Member", color = MaterialTheme.colorScheme.onPrimary) }
                    IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, stringResource(R.string.logout)) }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            LanguageToggleRow(currentLang, onChangeLanguage)

            RoyalCard {
                Text("Real-Time Club Overview", fontWeight = FontWeight.Bold)
                Text("Members: ${members.size} • Pending: $pendingCount • Approved: $approvedCount • Rejected: $rejectedCount")
                Text("Active: $activeCount • Inactive: $inactiveCount")
                Text("Verified Donations: ${summary.totalVerifiedDonations} • Income: ${summary.totalIncome} • Expenses: ${summary.totalExpenses} • Balance: ${summary.currentBalance}")
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(modules) { m ->
                    RoyalCard(Modifier.clickable { onNavigate(m.route) }) {
                        Icon(m.icon, null, tint = DeepOrange, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.height(6.dp))
                        Text(stringResource(m.labelRes), fontWeight = FontWeight.SemiBold)
                        if (m.badge.isNotBlank()) {
                            Text(m.badge, style = MaterialTheme.typography.bodySmall, color = DeepOrange)
                        }
                    }
                }
            }
        }
    }
}
