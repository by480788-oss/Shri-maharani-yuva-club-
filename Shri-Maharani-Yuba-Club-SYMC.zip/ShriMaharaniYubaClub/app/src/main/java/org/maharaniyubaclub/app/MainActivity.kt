package org.maharaniyubaclub.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.maharaniyubaclub.app.data.local.LocalePreferences
import org.maharaniyubaclub.app.ui.navigation.AppNavigation
import org.maharaniyubaclub.app.ui.theme.ShriMaharaniTheme

class MainActivity : AppCompatActivity() {
    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        val localePrefs = LocalePreferences(applicationContext)
        runBlocking {
            val saved = localePrefs.languageFlow.first()
            localePrefs.setLanguage(saved)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            val currentLang by localePrefs.languageFlow.collectAsState(initial = "en")
            ShriMaharaniTheme {
                AppNavigation(
                    currentLanguage = currentLang,
                    onChangeLanguage = { lang -> localePrefs.setLanguage(lang) }
                )
            }
        }
    }
}
