package org.maharaniyubaclub.app.ui.screens.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.ui.components.RoyalTopBar
import org.maharaniyubaclub.app.ui.viewmodel.AuthViewModel

@Composable
fun ForgotPasswordScreen(authVm: AuthViewModel, onBack: () -> Unit) {
    val state by authVm.state.collectAsState()
    var email by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.reset_password), onBack) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(email, { email = it }, label = { Text(stringResource(R.string.email_address)) }, modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { authVm.sendPasswordResetLink(email) }, enabled = !state.loading, modifier = Modifier.weight(1f)) {
                    Text("Reset Email Link")
                }
                OutlinedButton(onClick = { authVm.sendEmailOtp(email, "RESET") }, enabled = !state.loading, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.send_email_otp))
                }
            }

            if (state.emailOtpSent && !state.emailOtpVerified) {
                OutlinedTextField(otp, { otp = it }, label = { Text(stringResource(R.string.otp_code)) }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { authVm.verifyEmailOtp(email, otp, "RESET") }) {
                    Text(stringResource(R.string.verify_email_otp))
                }
            }

            if (state.emailOtpVerified) {
                OutlinedTextField(newPassword, { newPassword = it }, label = { Text(stringResource(R.string.password)) }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Button(onClick = { authVm.resetPasswordWithEmailOtp(email, newPassword, onBack) }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.reset_password))
                }
            }

            state.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            state.infoMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
    }
}
