package org.maharaniyubaclub.app.ui.screens.admin

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.data.model.MemberProfile
import org.maharaniyubaclub.app.ui.components.*
import org.maharaniyubaclub.app.ui.viewmodel.AdminViewModel

@Composable
fun AdminMembersScreen(adminVm: AdminViewModel, onBack: () -> Unit) {
    val members by adminVm.members.collectAsState()
    val msg by adminVm.message.collectAsState()
    var query by remember { mutableStateOf("") }
    var filterStatus by remember { mutableStateOf("ALL") }
    var showCreate by remember { mutableStateOf(false) }
    var editingMember by remember { mutableStateOf<MemberProfile?>(null) }

    val filtered = members.filter { m ->
        val matchesText = m.fullName.contains(query, true) || m.email.contains(query, true) ||
            m.phoneE164.contains(query) || m.memberCode.contains(query, true)
        val matchesFilter = when (filterStatus) {
            "PENDING" -> m.approvalStatus == "PENDING"
            "APPROVED" -> m.approvalStatus == "APPROVED"
            "REJECTED" -> m.approvalStatus == "REJECTED"
            "ACTIVE" -> m.activeStatus == "ACTIVE"
            "INACTIVE" -> m.activeStatus == "INACTIVE"
            else -> true
        }
        matchesText && matchesFilter
    }

    Scaffold(
        topBar = {
            RoyalTopBar(stringResource(R.string.admin_members), onBack, actions = {
                TextButton(onClick = { showCreate = true }) { Text("+ Add", color = MaterialTheme.colorScheme.onPrimary) }
            })
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(query, { query = it }, label = { Text(stringResource(R.string.search)) }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("ALL", "PENDING", "APPROVED", "REJECTED", "ACTIVE", "INACTIVE").forEach { f ->
                    FilterChip(selected = filterStatus == f, onClick = { filterStatus = f }, label = { Text(f) })
                }
            }
            msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            if (filtered.isEmpty()) EmptyStateBox()
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered, key = { it.uid }) { m ->
                    RoyalCard {
                        Text("${m.fullName} (${m.memberCode.ifBlank { "No ID" }})", fontWeight = FontWeight.Bold)
                        Text("${m.email} • ${m.phoneE164}")
                        Text("Approval: ${m.approvalStatus} | Status: ${m.activeStatus}")
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(onClick = { adminVm.updateMemberStatus(m.uid, "APPROVED", "ACTIVE") }) { Text(stringResource(R.string.approve)) }
                            OutlinedButton(onClick = { adminVm.updateMemberStatus(m.uid, "REJECTED", "INACTIVE") }) { Text(stringResource(R.string.reject)) }
                            OutlinedButton(onClick = {
                                val nextActive = if (m.activeStatus == "ACTIVE") "INACTIVE" else "ACTIVE"
                                adminVm.updateMemberStatus(m.uid, m.approvalStatus, nextActive)
                            }) { Text(if (m.activeStatus == "ACTIVE") "Deactivate" else "Activate") }
                            TextButton(onClick = { editingMember = m }) { Text("Edit") }
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var pass by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("Add Member") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Full Name") })
                    OutlinedTextField(email, { email = it }, label = { Text("Email") })
                    OutlinedTextField(phone, { phone = it }, label = { Text("Phone (+977...)") })
                    OutlinedTextField(pass, { pass = it }, label = { Text("Initial Password") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    adminVm.createMember(name, email, phone, "+977", pass)
                    showCreate = false
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }

    editingMember?.let { target ->
        var name by remember { mutableStateOf(target.fullName) }
        var address by remember { mutableStateOf(target.address) }
        AlertDialog(
            onDismissRequest = { editingMember = null },
            title = { Text("Edit Member") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Full Name") })
                    OutlinedTextField(address, { address = it }, label = { Text("Address") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    adminVm.updateMemberDetails(target.copy(fullName = name, address = address))
                    editingMember = null
                }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = { TextButton(onClick = { editingMember = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
