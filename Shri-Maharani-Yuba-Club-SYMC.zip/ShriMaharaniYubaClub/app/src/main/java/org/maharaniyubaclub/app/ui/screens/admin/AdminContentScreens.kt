package org.maharaniyubaclub.app.ui.screens.admin

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.data.model.*
import org.maharaniyubaclub.app.ui.components.*
import org.maharaniyubaclub.app.ui.viewmodel.AdminViewModel
import org.maharaniyubaclub.app.ui.viewmodel.MemberViewModel

@Composable
fun AdminAnnouncementsScreen(adminVm: AdminViewModel, memberVm: MemberViewModel, onBack: () -> Unit) {
    val list by memberVm.announcements.collectAsState()
    val msg by adminVm.message.collectAsState()
    var type by remember { mutableStateOf("ANNOUNCEMENT") }
    var titleEn by remember { mutableStateOf("") }
    var titleNe by remember { mutableStateOf("") }
    var bodyEn by remember { mutableStateOf("") }
    var bodyNe by remember { mutableStateOf("") }
    var sendPush by remember { mutableStateOf(true) }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.admin_announcements), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                RoyalCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = type == "ANNOUNCEMENT", onClick = { type = "ANNOUNCEMENT" }, label = { Text("Announcement") })
                        FilterChip(selected = type == "NEWS", onClick = { type = "NEWS" }, label = { Text("News") })
                    }
                    OutlinedTextField(titleEn, { titleEn = it }, label = { Text("Title (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(titleNe, { titleNe = it }, label = { Text("Title (नेपाली)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(bodyEn, { bodyEn = it }, label = { Text("Body (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(bodyNe, { bodyNe = it }, label = { Text("Body (नेपाली)") }, modifier = Modifier.fillMaxWidth())
                    Row { Checkbox(sendPush, { sendPush = it }); Text("Send Push Notification (FCM)") }
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                    Button(
                        onClick = {
                            if (titleEn.isNotBlank() && bodyEn.isNotBlank()) {
                                adminVm.publishAnnouncement(type, titleEn, titleNe, bodyEn, bodyNe, sendPush)
                                titleEn = ""; titleNe = ""; bodyEn = ""; bodyNe = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Publish") }
                }
            }
            if (list.isEmpty()) item { EmptyStateBox() }
            else items(list, key = { it.id }) { a ->
                RoyalCard {
                    Text("[${a.type}] ${a.titleEn} / ${a.titleNe}", fontWeight = FontWeight.Bold)
                    Text(a.bodyEn)
                    TextButton(onClick = { adminVm.deleteAnnouncement(a.id) }) { Text(stringResource(R.string.delete)) }
                }
            }
        }
    }
}

@Composable
fun AdminEventsAndActivitiesScreen(adminVm: AdminViewModel, memberVm: MemberViewModel, onBack: () -> Unit) {
    val events by memberVm.events.collectAsState()
    val activities by memberVm.activities.collectAsState()
    val msg by adminVm.message.collectAsState()

    var tab by remember { mutableIntStateOf(0) }
    var titleEn by remember { mutableStateOf("") }
    var titleNe by remember { mutableStateOf("") }
    var descEn by remember { mutableStateOf("") }
    var descNe by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var isPast by remember { mutableStateOf(false) }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { photoUri = it }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.admin_events), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Events") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Activities") })
                }
            }
            item {
                RoyalCard {
                    OutlinedTextField(titleEn, { titleEn = it }, label = { Text("Title (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(titleNe, { titleNe = it }, label = { Text("Title (नेपाली)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(descEn, { descEn = it }, label = { Text("Description (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(descNe, { descNe = it }, label = { Text("Description (नेपाली)") }, modifier = Modifier.fillMaxWidth())
                    if (tab == 0) {
                        OutlinedTextField(location, { location = it }, label = { Text("Location") }, modifier = Modifier.fillMaxWidth())
                        Row { Checkbox(isPast, { isPast = it }); Text("Mark as Past Event") }
                    }
                    OutlinedButton(onClick = { picker.launch("image/*") }) {
                        Text(if (photoUri == null) "Pick Photo (Optional)" else "Photo Selected")
                    }
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                    Button(
                        onClick = {
                            if (tab == 0) {
                                adminVm.saveEvent(ClubEvent(titleEn = titleEn, titleNe = titleNe, descriptionEn = descEn, descriptionNe = descNe, location = location, isPast = isPast), photoUri)
                            } else {
                                adminVm.saveActivity(ClubActivity(titleEn = titleEn, titleNe = titleNe, summaryEn = descEn, summaryNe = descNe), photoUri)
                            }
                            titleEn = ""; titleNe = ""; descEn = ""; descNe = ""; location = ""; photoUri = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.save)) }
                }
            }
            if (tab == 0) {
                items(events, key = { it.id }) { ev ->
                    RoyalCard {
                        Text("${ev.titleEn} (${if (ev.isPast) "Past" else "Upcoming"})", fontWeight = FontWeight.Bold)
                        Text(ev.location)
                        Row {
                            TextButton(onClick = { adminVm.saveEvent(ev.copy(isPast = !ev.isPast), null) }) { Text(if (ev.isPast) "Move to Upcoming" else "Move to Past") }
                            TextButton(onClick = { adminVm.deleteEvent(ev.id) }) { Text(stringResource(R.string.delete)) }
                        }
                    }
                }
            } else {
                items(activities, key = { it.id }) { act ->
                    RoyalCard {
                        Text(act.titleEn, fontWeight = FontWeight.Bold)
                        Text(act.summaryEn)
                        TextButton(onClick = { adminVm.deleteActivity(act.id) }) { Text(stringResource(R.string.delete)) }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminCommitteeScreen(adminVm: AdminViewModel, memberVm: MemberViewModel, onBack: () -> Unit) {
    val list by memberVm.committee.collectAsState()
    val msg by adminVm.message.collectAsState()
    var name by remember { mutableStateOf("") }
    var posEn by remember { mutableStateOf("") }
    var posNe by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var bioEn by remember { mutableStateOf("") }
    var bioNe by remember { mutableStateOf("") }
    var order by remember { mutableStateOf("1") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { photoUri = it }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.admin_committee), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                RoyalCard {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(posEn, { posEn = it }, label = { Text("Position (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(posNe, { posNe = it }, label = { Text("Position (नेपाली)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(contact, { contact = it }, label = { Text("Authorized Contact Info") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(bioEn, { bioEn = it }, label = { Text("Introduction (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(bioNe, { bioNe = it }, label = { Text("Introduction (नेपाली)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(order, { order = it }, label = { Text("Display Order") }, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = { picker.launch("image/*") }) { Text(if (photoUri == null) "Pick Photo" else "Photo Selected") }
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                    Button(onClick = {
                        adminVm.saveCommittee(
                            CommitteeMember(name = name, positionEn = posEn, positionNe = posNe, contactInfo = contact, bioEn = bioEn, bioNe = bioNe, orderIndex = order.toIntOrNull() ?: 1),
                            photoUri
                        )
                        name = ""; posEn = ""; posNe = ""; contact = ""; bioEn = ""; bioNe = ""; photoUri = null
                    }, modifier = Modifier.fillMaxWidth()) { Text("Add Committee Member") }
                }
            }
            items(list, key = { it.id }) { cm ->
                RoyalCard {
                    Text("${cm.name} — ${cm.positionEn}", fontWeight = FontWeight.Bold)
                    TextButton(onClick = { adminVm.deleteCommittee(cm.id) }) { Text(stringResource(R.string.delete)) }
                }
            }
        }
    }
}

@Composable
fun AdminGalleryScreen(adminVm: AdminViewModel, memberVm: MemberViewModel, onBack: () -> Unit) {
    val itemsList by memberVm.gallery.collectAsState()
    val msg by adminVm.message.collectAsState()
    var album by remember { mutableStateOf("") }
    var mediaType by remember { mutableStateOf("PHOTO") }
    var capEn by remember { mutableStateOf("") }
    var capNe by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<GalleryItem?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && album.isNotBlank()) adminVm.uploadMedia(album, mediaType, capEn, capNe, uri)
    }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.admin_gallery), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                RoyalCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = mediaType == "PHOTO", onClick = { mediaType = "PHOTO" }, label = { Text("PHOTO") })
                        FilterChip(selected = mediaType == "VIDEO", onClick = { mediaType = "VIDEO" }, label = { Text("VIDEO") })
                    }
                    OutlinedTextField(album, { album = it }, label = { Text("Album Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(capEn, { capEn = it }, label = { Text("Caption (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(capNe, { capNe = it }, label = { Text("Caption (नेपाली)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                    Button(
                        onClick = { picker.launch(if (mediaType == "VIDEO") "video/*" else "image/*") },
                        enabled = album.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Select & Upload $mediaType") }
                }
            }
            items(itemsList, key = { it.id }) { g ->
                RoyalCard {
                    Text("${g.albumName} • ${g.mediaType}", fontWeight = FontWeight.Bold)
                    if (g.mediaType == "PHOTO") AsyncImage(g.mediaUrl, null, Modifier.fillMaxWidth().height(150.dp))
                    Text("${g.captionEn} / ${g.captionNe}")
                    Row {
                        TextButton(onClick = { editing = g }) { Text("Edit Caption") }
                        TextButton(onClick = { adminVm.deleteMedia(g.id) }) { Text(stringResource(R.string.delete)) }
                    }
                }
            }
        }
    }

    editing?.let { g ->
        var eEn by remember { mutableStateOf(g.captionEn) }
        var eNe by remember { mutableStateOf(g.captionNe) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Edit Caption") },
            text = {
                Column {
                    OutlinedTextField(eEn, { eEn = it }, label = { Text("Caption (English)") })
                    OutlinedTextField(eNe, { eNe = it }, label = { Text("Caption (नेपाली)") })
                }
            },
            confirmButton = { Button(onClick = { adminVm.updateMediaCaption(g.id, eEn, eNe); editing = null }) { Text(stringResource(R.string.save)) } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
fun AdminSettingsScreen(adminVm: AdminViewModel, memberVm: MemberViewModel, onBack: () -> Unit) {
    val current by memberVm.clubSettings.collectAsState()
    val msg by adminVm.message.collectAsState()
    var s by remember(current) { mutableStateOf(current) }
    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) adminVm.uploadLogo(uri)
    }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.admin_settings), onBack) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { logoPicker.launch("image/*") }) { Text("Upload / Replace Official Club Logo") }
            OutlinedTextField(s.donationInstructionsEn, { s = s.copy(donationInstructionsEn = it) }, label = { Text("Donation Instructions (English)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.donationInstructionsNe, { s = s.copy(donationInstructionsNe = it) }, label = { Text("Donation Instructions (नेपाली)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.aboutEn, { s = s.copy(aboutEn = it) }, label = { Text("About Club (English)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.aboutNe, { s = s.copy(aboutNe = it) }, label = { Text("About Club (नेपाली)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.objectivesEn, { s = s.copy(objectivesEn = it) }, label = { Text("Objectives (English)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.objectivesNe, { s = s.copy(objectivesNe = it) }, label = { Text("Objectives (नेपाली)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.missionVisionEn, { s = s.copy(missionVisionEn = it) }, label = { Text("Mission & Vision (English)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.missionVisionNe, { s = s.copy(missionVisionNe = it) }, label = { Text("Mission & Vision (नेपाली)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.contactEmail, { s = s.copy(contactEmail = it) }, label = { Text("Official Contact Email") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.contactPhone, { s = s.copy(contactPhone = it) }, label = { Text("Official Contact Phone") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.contactAddress, { s = s.copy(contactAddress = it) }, label = { Text("Official Address") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.socialLinks, { s = s.copy(socialLinks = it) }, label = { Text("Official Social Media Links") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.termsEn, { s = s.copy(termsEn = it) }, label = { Text("Terms & Conditions (English)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.termsNe, { s = s.copy(termsNe = it) }, label = { Text("Terms & Conditions (नेपाली)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.privacyEn, { s = s.copy(privacyEn = it) }, label = { Text("Privacy Policy (English)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.privacyNe, { s = s.copy(privacyNe = it) }, label = { Text("Privacy Policy (नेपाली)") }, modifier = Modifier.fillMaxWidth())
            msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            Button(onClick = { adminVm.saveClubSettings(s) }, modifier = Modifier.fillMaxWidth()) { Text("Save All Club Content & Settings") }
        }
    }
}

@Composable
fun AdminActivityLogsScreen(adminVm: AdminViewModel, onBack: () -> Unit) {
    val logs by adminVm.activityLogs.collectAsState()
    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.admin_logs), onBack) }) { pad ->
        if (logs.isEmpty()) Box(Modifier.padding(pad)) { EmptyStateBox() }
        else LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(logs, key = { it.id }) { l ->
                RoyalCard {
                    Text("${l.action} (${l.targetCollection})", fontWeight = FontWeight.Bold)
                    Text("${l.adminEmail} • ${l.timestamp?.toDate()?.toString() ?: ""}", style = MaterialTheme.typography.bodySmall)
                    if (l.details.isNotBlank()) Text(l.details)
                }
            }
        }
    }
}

@Composable
fun AdminRolesScreen(adminVm: AdminViewModel, onBack: () -> Unit) {
    val admins by adminVm.admins.collectAsState()
    val msg by adminVm.message.collectAsState()
    var email by remember { mutableStateOf("") }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.admin_roles), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                RoyalCard {
                    Text("Super Admin Role Authorization", fontWeight = FontWeight.Bold)
                    OutlinedTextField(email, { email = it }, label = { Text("Registered User Email") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { adminVm.setAdminRole(email, true); email = "" }) { Text("Authorize Admin") }
                        OutlinedButton(onClick = { adminVm.setAdminRole(email, false); email = "" }) { Text("Revoke Admin") }
                    }
                }
            }
            items(admins, key = { it.uid }) { a ->
                RoyalCard {
                    Text("${a.fullName} (${a.role})", fontWeight = FontWeight.Bold)
                    Text(a.email)
                }
            }
        }
    }
}
