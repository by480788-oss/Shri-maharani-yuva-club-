package org.maharaniyubaclub.app.ui.viewmodel

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.maharaniyubaclub.app.data.model.UserSession
import org.maharaniyubaclub.app.data.repository.AuthRepository

data class AuthUiState(
    val loading: Boolean = false,
    val session: UserSession? = null,
    val sessionChecked: Boolean = false,
    val smsVerificationId: String? = null,
    val verifiedPhoneCredential: PhoneAuthCredential? = null,
    val smsVerified: Boolean = false,
    val emailOtpSent: Boolean = false,
    val emailOtpVerified: Boolean = false,
    val infoMessage: String? = null,
    val errorMessage: String? = null
)

class AuthViewModel(private val repo: AuthRepository = AuthRepository()) : ViewModel() {
    private val _state = MutableStateFlow(AuthUiState())
    val state = _state.asStateFlow()

    init {
        refreshSession()
    }

    fun refreshSession() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            try {
                val session = repo.loadCurrentSession()
                _state.value = _state.value.copy(loading = false, session = session, sessionChecked = true)
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, session = null, sessionChecked = true, errorMessage = e.localizedMessage)
            }
        }
    }

    fun clearMessages() {
        _state.value = _state.value.copy(errorMessage = null, infoMessage = null)
    }

    fun sendSmsOtp(activity: Activity, phoneE164: String) {
        _state.value = _state.value.copy(loading = true, errorMessage = null, infoMessage = null)
        repo.sendSmsOtp(
            activity = activity,
            phoneE164 = phoneE164,
            onCodeSent = { verId ->
                _state.value = _state.value.copy(loading = false, smsVerificationId = verId, infoMessage = "SMS OTP sent to $phoneE164")
            },
            onAutoVerified = { cred ->
                _state.value = _state.value.copy(loading = false, verifiedPhoneCredential = cred, smsVerified = true, infoMessage = "Mobile auto-verified.")
            },
            onFailed = { err ->
                _state.value = _state.value.copy(loading = false, errorMessage = err)
            }
        )
    }

    fun confirmSmsOtpCode(code: String) {
        val verId = _state.value.smsVerificationId ?: return
        val cred = PhoneAuthProvider.getCredential(verId, code.trim())
        _state.value = _state.value.copy(verifiedPhoneCredential = cred, smsVerified = true, infoMessage = "SMS OTP verified.")
    }

    fun sendEmailOtp(email: String, purpose: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null, infoMessage = null)
            try {
                repo.sendEmailOtp(email, purpose)
                _state.value = _state.value.copy(loading = false, emailOtpSent = true, infoMessage = "Email OTP sent to $email")
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    fun verifyEmailOtp(email: String, code: String, purpose: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            try {
                val ok = repo.verifyEmailOtp(email, code, purpose)
                _state.value = _state.value.copy(
                    loading = false,
                    emailOtpVerified = ok,
                    infoMessage = if (ok) "Email OTP verified." else null,
                    errorMessage = if (!ok) "Invalid OTP." else null
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    fun register(fullName: String, email: String, password: String, phoneE164: String, countryCode: String, lang: String, onSuccess: () -> Unit) {
        val cred = _state.value.verifiedPhoneCredential
        if (!_state.value.smsVerified || cred == null) {
            _state.value = _state.value.copy(errorMessage = "Please verify your mobile number via SMS OTP.")
            return
        }
        if (!_state.value.emailOtpVerified) {
            _state.value = _state.value.copy(errorMessage = "Please verify your email via Email OTP.")
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            try {
                val (emailDup, phoneDup) = repo.checkDuplicates(email, phoneE164)
                if (emailDup || phoneDup) {
                    _state.value = _state.value.copy(loading = false, errorMessage = "Email or mobile number already registered.")
                    return@launch
                }
                repo.completeRegistration(fullName, email, password, phoneE164, countryCode, cred, lang)
                val session = repo.loadCurrentSession()
                _state.value = _state.value.copy(loading = false, session = session, infoMessage = "Registration submitted.")
                onSuccess()
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    fun loginWithEmail(email: String, password: String, onSuccess: (UserSession) -> Unit) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            try {
                repo.signInWithEmail(email, password)
                val session = repo.loadCurrentSession() ?: error("Unable to load user profile.")
                _state.value = _state.value.copy(loading = false, session = session)
                onSuccess(session)
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    fun loginWithPhonePassword(phoneE164: String, password: String, onSuccess: (UserSession) -> Unit) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            try {
                repo.signInWithPhoneAndPassword(phoneE164, password)
                val session = repo.loadCurrentSession() ?: error("Unable to load user profile.")
                _state.value = _state.value.copy(loading = false, session = session)
                onSuccess(session)
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    fun loginWithSmsOtpCode(code: String, onSuccess: (UserSession) -> Unit) {
        val verId = _state.value.smsVerificationId ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            try {
                repo.signInWithPhoneCredential(PhoneAuthProvider.getCredential(verId, code.trim()))
                val session = repo.loadCurrentSession() ?: error("Unable to load user profile.")
                _state.value = _state.value.copy(loading = false, session = session)
                onSuccess(session)
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    fun sendPasswordResetLink(email: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            try {
                repo.sendPasswordResetEmail(email)
                _state.value = _state.value.copy(loading = false, infoMessage = "Password reset link sent to $email")
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    fun resetPasswordWithEmailOtp(email: String, newPass: String, onDone: () -> Unit) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            try {
                repo.resetPasswordWithEmailOtp(email, newPass)
                _state.value = _state.value.copy(loading = false, infoMessage = "Password updated. You may now log in.")
                onDone()
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    fun changePassword(current: String, newPass: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, errorMessage = null)
            try {
                repo.changePassword(current, newPass)
                _state.value = _state.value.copy(loading = false, infoMessage = "Password changed successfully.")
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, errorMessage = e.localizedMessage)
            }
        }
    }

    fun logout(onDone: () -> Unit) {
        repo.logout()
        _state.value = AuthUiState(sessionChecked = true)
        onDone()
    }
}
