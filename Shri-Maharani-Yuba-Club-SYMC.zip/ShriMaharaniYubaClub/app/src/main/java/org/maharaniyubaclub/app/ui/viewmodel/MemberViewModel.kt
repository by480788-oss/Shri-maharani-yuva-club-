package org.maharaniyubaclub.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.maharaniyubaclub.app.data.model.*
import org.maharaniyubaclub.app.data.repository.ClubRepository

class MemberViewModel(private val repo: ClubRepository = ClubRepository()) : ViewModel() {
    val clubSettings = repo.observeClubSettings().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ClubSettings())
    val announcements = repo.observeAnnouncements().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val events = repo.observeEvents().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val activities = repo.observeActivities().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val committee = repo.observeCommittee().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val gallery = repo.observeGallery().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val transactions = repo.observeFundTransactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val fundSummary: StateFlow<FundSummary> = transactions.map { list ->
        val verifiedDonations = list.filter { it.type == "INCOME" && it.category == "DONATION" }.sumOf { it.amount }
        val income = list.filter { it.type == "INCOME" }.sumOf { it.amount }
        val expenses = list.filter { it.type == "EXPENSE" }.sumOf { it.amount }
        FundSummary(verifiedDonations, income, expenses)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FundSummary())

    private val _myDonations = MutableStateFlow<List<DonationRecord>>(emptyList())
    val myDonations = _myDonations.asStateFlow()

    private val _statusMsg = MutableStateFlow<String?>(null)
    val statusMsg = _statusMsg.asStateFlow()

    fun loadMyDonations(uid: String) {
        viewModelScope.launch {
            repo.observeMyDonations(uid).collect { _myDonations.value = it }
        }
    }

    fun clearMessage() { _statusMsg.value = null }

    fun markAnnouncementRead(id: String) {
        viewModelScope.launch { repo.markAnnouncementRead(id) }
    }

    fun submitDonation(profile: MemberProfile, amountText: String, ref: String, proofUri: Uri?) {
        val amount = amountText.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            _statusMsg.value = "Enter a valid positive donation amount."
            return
        }
        if (ref.isBlank()) {
            _statusMsg.value = "Payment reference number is required."
            return
        }
        viewModelScope.launch {
            try {
                repo.submitDonation(profile, amount, ref, proofUri)
                _statusMsg.value = "Donation record submitted. Awaiting Admin verification."
            } catch (e: Exception) {
                _statusMsg.value = e.localizedMessage
            }
        }
    }

    fun updateProfile(uid: String, fullName: String, address: String, showPhone: Boolean, showEmail: Boolean, avatarUri: Uri?, onDone: () -> Unit) {
        viewModelScope.launch {
            try {
                repo.updateMyProfile(uid, fullName, address, showPhone, showEmail, avatarUri)
                _statusMsg.value = "Profile updated."
                onDone()
            } catch (e: Exception) {
                _statusMsg.value = e.localizedMessage
            }
        }
    }

    fun submitSupport(subject: String, msg: String) {
        if (subject.isBlank() || msg.isBlank()) {
            _statusMsg.value = "Subject and message are required."
            return
        }
        viewModelScope.launch {
            try {
                repo.sendSupportInquiry(subject, msg)
                _statusMsg.value = "Support inquiry sent to Club Admin."
            } catch (e: Exception) {
                _statusMsg.value = e.localizedMessage
            }
        }
    }
}
