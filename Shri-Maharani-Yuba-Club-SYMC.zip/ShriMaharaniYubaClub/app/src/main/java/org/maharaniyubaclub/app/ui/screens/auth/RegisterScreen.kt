package org.maharaniyubaclub.app.ui.screens.auth

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.data.model.SUPPORTED_COUNTRIES
import org.maharaniyubaclub.app.ui.components.RoyalTopBar
import org.maharaniyubaclub.app.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(
    currentLang: String,
    authVm: AuthViewModel,
    onBack: () -> Unit,
    onRegistered: () -> Unit
) {
    val state by authVm.state.collectAsState()
    val context = LocalContext.current
    val activity = context as Activity

    var fullName by remember { mutableStateOf("") }
    var selectedCountry by remember { mutableStateOf(SUPPORTED_COUNTRIES.first()) }
    var countryExpanded by remember { mutableStateOf(false) }
    var mobileLocal by remember { mutableStateOf("") }
    var smsCode by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var emailOtp by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var acceptedTerms by remember { mutableStateOf(false) }
    var localError by remember { mutableStateOf<String?>(null) }

    val phoneE164 = "${selectedCountry.dialCode}${mobileLocal.filter { it.isDigit() }}"

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.create_account), onBack) }) { pad ->
        Column(
            modifier = Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text(stringResource(R.string.full_name)) },
                modifier = Modifier.fillMaxWidth()
            )

            ExposedDropdownMenuBox(expanded = countryExpanded, onExpandedChange = { countryExpanded = it }) {
                OutlinedTextField(
                    value = "${selectedCountry.flag} ${selectedCountry.name} (${selectedCountry.dialCode})",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(stringResource(R.string.country_code)) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = countryExpanded, onDismissRequest = { countryExpanded = false }) {
                    SUPPORTED_COUNTRIES.forEach { item ->
                        DropdownMenuItem(
                            text = { Text("${item.flag} ${item.name} (${item.dialCode})") },
                            onClick = { selectedCountry = item; countryExpanded = false }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = mobileLocal,
                onValueChange = { mobileLocal = it },
                label = { Text(stringResource(R.string.mobile_number)) },
                modifier = Modifier.fillMaxWidth()
            )

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (mobileLocal.filter { it.isDigit() }.length < 7) localError = "Enter a valid mobile number."
                        else { localError = null; authVm.sendSmsOtp(activity, phoneE164) }
                    },
                    enabled = !state.loading && !state.smsVerified
                ) { Text(stringResource(R.string.send_sms_otp)) }
                Text(if (state.smsVerified) stringResource(R.string.verified) else stringResource(R.string.not_verified))
            }

            if (state.smsVerificationId != null && !state.smsVerified) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = smsCode,
                        onValueChange = { smsCode = it },
                        label = { Text(stringResource(R.string.otp_code)) },
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = { authVm.confirmSmsOtpCode(smsCode) }) {
                        Text(stringResource(R.string.verify_sms_otp))
                    }
                }
            }

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text(stringResource(R.string.email_address)) },
                modifier = Modifier.fillMaxWidth()
            )

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (!email.contains("@")) localError = "Enter a valid email."
                        else { localError = null; authVm.sendEmailOtp(email, "REGISTRATION") }
                    },
                    enabled = !state.loading && !state.emailOtpVerified
                ) { Text(stringResource(R.string.send_email_otp)) }
                Text(if (state.emailOtpVerified) stringResource(R.string.verified) else stringResource(R.string.not_verified))
            }

            if (state.emailOtpSent && !state.emailOtpVerified) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = emailOtp,
                        onValueChange = { emailOtp = it },
                        label = { Text(stringResource(R.string.otp_code)) },
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = { authVm.verifyEmailOtp(email, emailOtp, "REGISTRATION") }) {
                        Text(stringResource(R.string.verify_email_otp))
                    }
                }
            }

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text(stringResource(R.string.password)) },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text(stringResource(R.string.confirm_password)) },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = acceptedTerms, onCheckedChange = { acceptedTerms = it })
                Text(stringResource(R.string.accept_terms))
            }

            (localError ?: state.errorMessage)?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            state.infoMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary) }

            Button(
                onClick = {
                    when {
                        fullName.isBlank() -> localError = "Full name is required."
                        password.length < 8 -> localError = "Password must be at least 8 characters."
                        password != confirmPassword -> localError = "Passwords do not match."
                        !acceptedTerms -> localError = "You must accept Terms & Conditions."
                        else -> {
                            localError = null
                            authVm.register(fullName, email, password, phoneE164, selectedCountry.dialCode, currentLang, onRegistered)
                        }
                    }
                },
                enabled = !state.loading,
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text(stringResource(R.string.register_submit))
            }
        }
    }
}
