package org.maharaniyubaclub.app.ui.screens.auth

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.data.model.SUPPORTED_COUNTRIES
import org.maharaniyubaclub.app.data.model.UserSession
import org.maharaniyubaclub.app.ui.components.RoyalTopBar
import org.maharaniyubaclub.app.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    authVm: AuthViewModel,
    onBack: () -> Unit,
    onForgotPassword: () -> Unit,
    onLoggedIn: (UserSession) -> Unit
) {
    val state by authVm.state.collectAsState()
    val activity = LocalContext.current as Activity

    var tabIndex by remember { mutableIntStateOf(0) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var country by remember { mutableStateOf(SUPPORTED_COUNTRIES.first()) }
    var countryOpen by remember { mutableStateOf(false) }
    var mobileLocal by remember { mutableStateOf("") }
    var otpCode by remember { mutableStateOf("") }

    val phoneE164 = "${country.dialCode}${mobileLocal.filter { it.isDigit() }}"

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.login), onBack) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            TabRow(selectedTabIndex = tabIndex) {
                Tab(selected = tabIndex == 0, onClick = { tabIndex = 0 }, text = { Text(stringResource(R.string.login_email_tab)) })
                Tab(selected = tabIndex == 1, onClick = { tabIndex = 1 }, text = { Text(stringResource(R.string.login_phone_tab)) })
                Tab(selected = tabIndex == 2, onClick = { tabIndex = 2 }, text = { Text(stringResource(R.string.login_otp_tab)) })
            }

            if (tabIndex == 0) {
                OutlinedTextField(email, { email = it }, label = { Text(stringResource(R.string.email_address)) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(password, { password = it }, label = { Text(stringResource(R.string.password)) }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Button(
                    onClick = { authVm.loginWithEmail(email, password, onLoggedIn) },
                    enabled = !state.loading,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.login)) }
            } else {
                ExposedDropdownMenuBox(expanded = countryOpen, onExpandedChange = { countryOpen = it }) {
                    OutlinedTextField(
                        value = "${country.flag} ${country.dialCode}",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text(stringResource(R.string.country_code)) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = countryOpen, onDismissRequest = { countryOpen = false }) {
                        SUPPORTED_COUNTRIES.forEach {
                            DropdownMenuItem(text = { Text("${it.flag} ${it.name} (${it.dialCode})") }, onClick = { country = it; countryOpen = false })
                        }
                    }
                }
                OutlinedTextField(mobileLocal, { mobileLocal = it }, label = { Text(stringResource(R.string.mobile_number)) }, modifier = Modifier.fillMaxWidth())

                if (tabIndex == 1) {
                    OutlinedTextField(password, { password = it }, label = { Text(stringResource(R.string.password)) }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = { authVm.loginWithPhonePassword(phoneE164, password, onLoggedIn) },
                        enabled = !state.loading,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.login)) }
                } else {
                    Button(onClick = { authVm.sendSmsOtp(activity, phoneE164) }, enabled = !state.loading) {
                        Text(stringResource(R.string.send_sms_otp))
                    }
                    if (state.smsVerificationId != null) {
                        OutlinedTextField(otpCode, { otpCode = it }, label = { Text(stringResource(R.string.otp_code)) }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { authVm.loginWithSmsOtpCode(otpCode, onLoggedIn) }, enabled = !state.loading, modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.verify_sms_otp))
                        }
                    }
                }
            }

            TextButton(onClick = onForgotPassword) { Text(stringResource(R.string.forgot_password)) }
            state.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            state.infoMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        }
    }
}
