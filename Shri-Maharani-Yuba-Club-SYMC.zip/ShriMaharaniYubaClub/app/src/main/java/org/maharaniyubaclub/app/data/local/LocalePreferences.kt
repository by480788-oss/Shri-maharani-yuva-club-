package org.maharaniyubaclub.app.data.local

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("club_prefs")

class LocalePreferences(private val context: Context) {
    private val langKey = stringPreferencesKey("preferred_language")

    val languageFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[langKey] ?: "en"
    }

    suspend fun setLanguage(langCode: String) {
        val safeCode = if (langCode == "ne") "ne" else "en"
        context.dataStore.edit { it[langKey] = safeCode }
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(safeCode))
    }
}
