package org.maharaniyubaclub.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.maharaniyubaclub.app.data.model.*
import org.maharaniyubaclub.app.data.repository.AdminRepository

class AdminViewModel(private val repo: AdminRepository = AdminRepository()) : ViewModel() {
    val members = repo.observeAllMembers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val donations = repo.observeAllDonations().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val admins = repo.observeAdmins().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val activityLogs = repo.observeActivityLogs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()

    fun clearMessage() { _message.value = null }

    private fun runTask(successMsg: String? = null, block: suspend () -> String?) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val res = block()
                _message.value = res ?: successMsg ?: "Completed."
            } catch (e: Exception) {
                _message.value = e.localizedMessage ?: "Operation failed."
            } finally {
                _busy.value = false
            }
        }
    }

    fun updateMemberStatus(uid: String, approval: String, active: String) =
        runTask("Member status updated.") { repo.updateMemberStatus(uid, approval, active); null }

    fun createMember(name: String, email: String, phone: String, code: String, pass: String) =
        runTask("Member added.") { repo.createMember(name, email, phone, code, pass); null }

    fun updateMemberDetails(member: MemberProfile) =
        runTask("Member updated.") { repo.updateMemberDetails(member); null }

    fun publishAnnouncement(type: String, tEn: String, tNe: String, bEn: String, bNe: String, push: Boolean) =
        runTask { repo.publishAnnouncement(type, tEn, tNe, bEn, bNe, push) }

    fun deleteAnnouncement(id: String) =
        runTask("Deleted.") { repo.deleteAnnouncement(id); null }

    fun saveEvent(event: ClubEvent, photoUri: Uri?) =
        runTask("Event saved.") { repo.saveEvent(event, photoUri); null }

    fun deleteEvent(id: String) =
        runTask("Event deleted.") { repo.deleteEvent(id); null }

    fun saveActivity(act: ClubActivity, photoUri: Uri?) =
        runTask("Activity saved.") { repo.saveActivity(act, photoUri); null }

    fun deleteActivity(id: String) =
        runTask("Activity deleted.") { repo.deleteActivity(id); null }

    fun saveCommittee(member: CommitteeMember, uri: Uri?) =
        runTask("Committee saved.") { repo.saveCommitteeMember(member, uri); null }

    fun deleteCommittee(id: String) =
        runTask("Committee member removed.") { repo.deleteCommitteeMember(id); null }

    fun uploadMedia(album: String, type: String, capEn: String, capNe: String, uri: Uri) =
        runTask("Media uploaded.") { repo.uploadGalleryMedia(album, type, capEn, capNe, uri); null }

    fun updateMediaCaption(id: String, capEn: String, capNe: String) =
        runTask("Caption updated.") { repo.updateGalleryCaption(id, capEn, capNe); null }

    fun deleteMedia(id: String) =
        runTask("Media removed.") { repo.deleteGalleryItem(id); null }

    fun uploadQr(uri: Uri) = runTask("Donation QR updated.") { repo.uploadDonationQr(uri); null }
    fun removeQr() = runTask("Donation QR removed.") { repo.removeDonationQr(); null }
    fun uploadLogo(uri: Uri) = runTask("Official logo updated.") { repo.uploadOfficialLogo(uri); null }

    fun verifyDonation(id: String, decision: String, note: String) =
        runTask("Donation $decision.") { repo.verifyDonation(id, decision, note); null }

    fun addTransaction(type: String, category: String, amount: Double, dEn: String, dNe: String) =
        runTask("Transaction recorded.") { repo.addFundTransaction(type, category, amount, dEn, dNe); null }

    fun saveClubSettings(settings: ClubSettings) =
        runTask("Club settings saved.") { repo.saveClubSettings(settings); null }

    fun setAdminRole(email: String, grant: Boolean) =
        runTask("Admin authorization updated.") { repo.setAdminRole(email, grant); null }
}
