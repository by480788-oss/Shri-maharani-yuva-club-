package org.maharaniyubaclub.app.ui.navigation

import androidx.compose.runtime.*
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.launch
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.data.model.MemberProfile
import org.maharaniyubaclub.app.data.model.UserSession
import org.maharaniyubaclub.app.ui.components.localized
import org.maharaniyubaclub.app.ui.screens.admin.*
import org.maharaniyubaclub.app.ui.screens.auth.*
import org.maharaniyubaclub.app.ui.screens.member.*
import org.maharaniyubaclub.app.ui.viewmodel.AdminViewModel
import org.maharaniyubaclub.app.ui.viewmodel.AuthViewModel
import org.maharaniyubaclub.app.ui.viewmodel.MemberViewModel

@Composable
fun AppNavigation(
    currentLanguage: String,
    onChangeLanguage: suspend (String) -> Unit
) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()
    val authVm: AuthViewModel = viewModel()
    val memberVm: MemberViewModel = viewModel()
    val adminVm: AdminViewModel = viewModel()

    val authState by authVm.state.collectAsState()
    val settings by memberVm.clubSettings.collectAsState()
    val session = authState.session ?: UserSession()

    val changeLang: (String) -> Unit = { code -> scope.launch { onChangeLanguage(code) } }

    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            SplashScreen(
                logoUrl = settings.officialLogoUrl,
                sessionChecked = authState.sessionChecked,
                isLoggedIn = authState.session != null,
                isAdmin = session.isAdmin || session.isSuperAdmin,
                onNavigatePublic = { navController.navigate("public_home") { popUpTo("splash") { inclusive = true } } },
                onNavigateMember = { navController.navigate("member_dashboard") { popUpTo("splash") { inclusive = true } } },
                onNavigateAdmin = { navController.navigate("admin_dashboard") { popUpTo("splash") { inclusive = true } } }
            )
        }

        composable("public_home") {
            PublicHomeScreen(
                currentLang = currentLanguage,
                settings = settings,
                onChangeLanguage = changeLang,
                onLoginClick = { authVm.clearMessages(); navController.navigate("login") },
                onRegisterClick = { authVm.clearMessages(); navController.navigate("register") },
                onAboutClick = { navController.navigate("about") },
                onContactClick = { navController.navigate("contact") }
            )
        }

        composable("login") {
            LoginScreen(
                authVm = authVm,
                onBack = { navController.popBackStack() },
                onForgotPassword = { authVm.clearMessages(); navController.navigate("forgot_password") },
                onLoggedIn = { s ->
                    val target = if (s.isAdmin || s.isSuperAdmin) "admin_dashboard" else "member_dashboard"
                    navController.navigate(target) { popUpTo("public_home") { inclusive = true } }
                }
            )
        }

        composable("register") {
            RegisterScreen(
                currentLang = currentLanguage,
                authVm = authVm,
                onBack = { navController.popBackStack() },
                onRegistered = { navController.navigate("member_dashboard") { popUpTo("public_home") { inclusive = true } } }
            )
        }

        composable("forgot_password") {
            ForgotPasswordScreen(authVm = authVm, onBack = { navController.popBackStack() })
        }

        composable("member_dashboard") {
            MemberDashboardScreen(
                currentLang = currentLanguage,
                session = session,
                settings = settings,
                onChangeLanguage = changeLang,
                onNavigate = { route -> navController.navigate(route) },
                onOpenAdmin = { if (session.isAdmin || session.isSuperAdmin) navController.navigate("admin_dashboard") },
                onLogout = { authVm.logout { navController.navigate("public_home") { popUpTo(0) } } }
            )
        }

        composable("profile") { MemberProfileScreen(session, memberVm, authVm) { navController.popBackStack() } }
        composable("announcements") { AnnouncementsListScreen(currentLanguage, false, session.uid, memberVm) { navController.popBackStack() } }
        composable("news") { AnnouncementsListScreen(currentLanguage, true, session.uid, memberVm) { navController.popBackStack() } }
        composable("events_upcoming") { EventsListScreen(currentLanguage, false, memberVm) { navController.popBackStack() } }
        composable("events_past") { EventsListScreen(currentLanguage, true, memberVm) { navController.popBackStack() } }
        composable("activities") { ActivitiesListScreen(currentLanguage, memberVm) { navController.popBackStack() } }
        composable("committee") { CommitteeScreen(currentLanguage, memberVm) { navController.popBackStack() } }
        composable("gallery_photo") { GalleryScreen(currentLanguage, false, memberVm) { navController.popBackStack() } }
        composable("gallery_video") { GalleryScreen(currentLanguage, true, memberVm) { navController.popBackStack() } }
        composable("donation") {
            DonationScreen(currentLanguage, session.memberProfile ?: MemberProfile(uid = session.uid), memberVm) { navController.popBackStack() }
        }
        composable("fund_summary") { FundSummaryScreen(currentLanguage, memberVm) { navController.popBackStack() } }

        composable("about") {
            val body = listOf(
                localized(currentLanguage, settings.aboutEn, settings.aboutNe),
                localized(currentLanguage, settings.objectivesEn, settings.objectivesNe),
                localized(currentLanguage, settings.missionVisionEn, settings.missionVisionNe)
            ).filter { it.isNotBlank() }.joinToString("\n\n")
            ClubInfoDocumentScreen(stringResource(R.string.about_club), body) { navController.popBackStack() }
        }
        composable("contact") {
            val info = listOfNotNull(
                settings.contactEmail.takeIf { it.isNotBlank() }?.let { "Email: $it" },
                settings.contactPhone.takeIf { it.isNotBlank() }?.let { "Phone: $it" },
                settings.contactAddress.takeIf { it.isNotBlank() }?.let { "Address: $it" },
                settings.socialLinks.takeIf { it.isNotBlank() }?.let { "Social: $it" }
            ).joinToString("\n")
            ClubInfoDocumentScreen(stringResource(R.string.contact_us), info) { navController.popBackStack() }
        }
        composable("terms") {
            ClubInfoDocumentScreen(stringResource(R.string.terms_conditions), localized(currentLanguage, settings.termsEn, settings.termsNe)) { navController.popBackStack() }
        }
        composable("privacy") {
            ClubInfoDocumentScreen(stringResource(R.string.privacy_policy), localized(currentLanguage, settings.privacyEn, settings.privacyNe)) { navController.popBackStack() }
        }
        composable("help") {
            SettingsAndSupportScreen(currentLanguage, changeLang, authVm, memberVm, { navController.popBackStack() }) {
                navController.navigate("public_home") { popUpTo(0) }
            }
        }
        composable("settings") {
            SettingsAndSupportScreen(currentLanguage, changeLang, authVm, memberVm, { navController.popBackStack() }) {
                navController.navigate("public_home") { popUpTo(0) }
            }
        }

        composable("admin_dashboard") {
            AdminDashboardScreen(
                currentLang = currentLanguage,
                session = session,
                adminVm = adminVm,
                memberVm = memberVm,
                onChangeLanguage = changeLang,
                onNavigate = { route -> adminVm.clearMessage(); navController.navigate(route) },
                onMemberView = { navController.navigate("member_dashboard") },
                onLogout = { authVm.logout { navController.navigate("public_home") { popUpTo(0) } } }
            )
        }
        composable("admin_members") { AdminMembersScreen(adminVm) { navController.popBackStack() } }
        composable("admin_donations") { AdminDonationsScreen(adminVm, memberVm) { navController.popBackStack() } }
        composable("admin_funds") { AdminFundsScreen(adminVm, memberVm) { navController.popBackStack() } }
        composable("admin_announcements") { AdminAnnouncementsScreen(adminVm, memberVm) { navController.popBackStack() } }
        composable("admin_events") { AdminEventsAndActivitiesScreen(adminVm, memberVm) { navController.popBackStack() } }
        composable("admin_committee") { AdminCommitteeScreen(adminVm, memberVm) { navController.popBackStack() } }
        composable("admin_gallery") { AdminGalleryScreen(adminVm, memberVm) { navController.popBackStack() } }
        composable("admin_settings") { AdminSettingsScreen(adminVm, memberVm) { navController.popBackStack() } }
        composable("admin_logs") { AdminActivityLogsScreen(adminVm) { navController.popBackStack() } }
        composable("admin_roles") { AdminRolesScreen(adminVm) { navController.popBackStack() } }
    }
}
