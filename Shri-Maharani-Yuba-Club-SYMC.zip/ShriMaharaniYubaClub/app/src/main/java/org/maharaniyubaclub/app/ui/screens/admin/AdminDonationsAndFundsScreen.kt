package org.maharaniyubaclub.app.ui.screens.admin

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.ui.components.*
import org.maharaniyubaclub.app.ui.viewmodel.AdminViewModel
import org.maharaniyubaclub.app.ui.viewmodel.MemberViewModel

@Composable
fun AdminDonationsScreen(adminVm: AdminViewModel, memberVm: MemberViewModel, onBack: () -> Unit) {
    val settings by memberVm.clubSettings.collectAsState()
    val donations by adminVm.donations.collectAsState()
    val msg by adminVm.message.collectAsState()
    val qrPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) adminVm.uploadQr(uri)
    }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.admin_donations), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                RoyalCard {
                    Text("Club Donation QR Management", fontWeight = FontWeight.Bold)
                    if (settings.donationQrUrl.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        AsyncImage(settings.donationQrUrl, "Donation QR", Modifier.fillMaxWidth().height(200.dp))
                    } else Text("No QR uploaded yet.")
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { qrPicker.launch("image/*") }) { Text(if (settings.donationQrUrl.isBlank()) "Upload QR" else "Replace QR") }
                        if (settings.donationQrUrl.isNotBlank()) {
                            OutlinedButton(onClick = { adminVm.removeQr() }) { Text("Remove QR") }
                        }
                    }
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                }
            }
            if (donations.isEmpty()) item { EmptyStateBox() }
            else items(donations, key = { it.id }) { d ->
                var note by remember { mutableStateOf("") }
                RoyalCard {
                    Text("${d.memberName} (${d.memberCode}) • ${d.currency} ${d.amount}", fontWeight = FontWeight.Bold)
                    Text("Ref: ${d.referenceNumber} • Status: ${d.status}")
                    if (d.proofUrl.isNotBlank()) {
                        AsyncImage(d.proofUrl, "Payment Proof", Modifier.fillMaxWidth().height(150.dp))
                    }
                    if (d.status == "PENDING") {
                        OutlinedTextField(note, { note = it }, label = { Text("Verification Note") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { adminVm.verifyDonation(d.id, "VERIFIED", note) }) { Text("Verify & Credit") }
                            OutlinedButton(onClick = { adminVm.verifyDonation(d.id, "REJECTED", note) }) { Text(stringResource(R.string.reject)) }
                        }
                    } else if (d.adminNote.isNotBlank()) Text("Note: ${d.adminNote}")
                }
            }
        }
    }
}

@Composable
fun AdminFundsScreen(adminVm: AdminViewModel, memberVm: MemberViewModel, onBack: () -> Unit) {
    val summary by memberVm.fundSummary.collectAsState()
    val txs by memberVm.transactions.collectAsState()
    val msg by adminVm.message.collectAsState()

    var type by remember { mutableStateOf("INCOME") }
    var category by remember { mutableStateOf("MEMBERSHIP_FEE") }
    var amountText by remember { mutableStateOf("") }
    var descEn by remember { mutableStateOf("") }
    var descNe by remember { mutableStateOf("") }

    val categoryTotals = txs.groupBy { "${it.type}: ${it.category}" }
        .mapValues { entry -> entry.value.sumOf { it.amount } }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.admin_funds), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                RoyalCard {
                    Text("Financial Summary (Genuine Ledger)", fontWeight = FontWeight.Bold)
                    Text("${stringResource(R.string.total_verified_donations)}: ${summary.totalVerifiedDonations}")
                    Text("${stringResource(R.string.total_income)}: ${summary.totalIncome}")
                    Text("${stringResource(R.string.total_expenses)}: ${summary.totalExpenses}")
                    Text("${stringResource(R.string.current_balance)}: ${summary.currentBalance}", fontWeight = FontWeight.Bold)
                    if (categoryTotals.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Report by Category:", fontWeight = FontWeight.SemiBold)
                        categoryTotals.forEach { (cat, amt) -> Text("• $cat = $amt") }
                    }
                }
            }
            item {
                RoyalCard {
                    Text("Record Income / Expense", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = type == "INCOME", onClick = { type = "INCOME" }, label = { Text("INCOME") })
                        FilterChip(selected = type == "EXPENSE", onClick = { type = "EXPENSE" }, label = { Text("EXPENSE") })
                    }
                    OutlinedTextField(category, { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(amountText, { amountText = it }, label = { Text("Amount") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(descEn, { descEn = it }, label = { Text("Description (English)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(descNe, { descNe = it }, label = { Text("Description (नेपाली)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                    Button(
                        onClick = {
                            val amt = amountText.toDoubleOrNull() ?: return@Button
                            if (amt > 0 && category.isNotBlank()) {
                                adminVm.addTransaction(type, category, amt, descEn, descNe)
                                amountText = ""; descEn = ""; descNe = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save Financial Record") }
                }
            }
            if (txs.isEmpty()) item { EmptyStateBox() }
            else items(txs, key = { it.id }) { t ->
                RoyalCard {
                    Text("${t.type} • ${t.category}: ${t.amount}", fontWeight = FontWeight.Bold)
                    Text(t.descriptionEn)
                    if (t.descriptionNe.isNotBlank()) Text(t.descriptionNe)
                }
            }
        }
    }
}
