package org.maharaniyubaclub.app.ui.screens.member

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.data.model.*
import org.maharaniyubaclub.app.ui.components.*
import org.maharaniyubaclub.app.ui.theme.DeepOrange
import org.maharaniyubaclub.app.ui.viewmodel.AuthViewModel
import org.maharaniyubaclub.app.ui.viewmodel.MemberViewModel

@Composable
fun MemberProfileScreen(
    session: UserSession,
    memberVm: MemberViewModel,
    authVm: AuthViewModel,
    onBack: () -> Unit
) {
    val profile = session.memberProfile ?: MemberProfile()
    var fullName by remember(profile) { mutableStateOf(profile.fullName) }
    var address by remember(profile) { mutableStateOf(profile.address) }
    var showPhone by remember(profile) { mutableStateOf(profile.privacyShowPhone) }
    var showEmail by remember(profile) { mutableStateOf(profile.privacyShowEmail) }
    var avatarUri by remember { mutableStateOf<Uri?>(null) }
    val msg by memberVm.statusMsg.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { avatarUri = it }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.profile), onBack) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            RoyalCard {
                if (profile.photoUrl.isNotBlank()) {
                    AsyncImage(profile.photoUrl, profile.fullName, Modifier.size(80.dp), contentScale = ContentScale.Crop)
                    Spacer(Modifier.height(8.dp))
                }
                Text("${stringResource(R.string.member_id)}: ${profile.memberCode.ifBlank { "Pending" }}", fontWeight = FontWeight.Bold)
                Text("${stringResource(R.string.status)}: ${profile.approvalStatus} / ${profile.activeStatus}")
                Text("Email: ${profile.email}")
                Text("Mobile: ${profile.phoneE164}")
            }
            Button(onClick = { picker.launch("image/*") }) { Text("Choose Profile Photo") }
            OutlinedTextField(fullName, { fullName = it }, label = { Text(stringResource(R.string.full_name)) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(address, { address = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
            Row { Checkbox(showPhone, { showPhone = it }); Text("Allow approved members to see my phone") }
            Row { Checkbox(showEmail, { showEmail = it }); Text("Allow approved members to see my email") }
            msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            Button(
                onClick = { memberVm.updateProfile(session.uid, fullName, address, showPhone, showEmail, avatarUri) { authVm.refreshSession() } },
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.save)) }
        }
    }
}

@Composable
fun AnnouncementsListScreen(
    lang: String,
    onlyNews: Boolean,
    uid: String,
    memberVm: MemberViewModel,
    onBack: () -> Unit
) {
    val all by memberVm.announcements.collectAsState()
    val items = all.filter { if (onlyNews) it.type == "NEWS" else it.type == "ANNOUNCEMENT" }
    Scaffold(topBar = { RoyalTopBar(stringResource(if (onlyNews) R.string.news_updates else R.string.announcements), onBack) }) { pad ->
        if (items.isEmpty()) Box(Modifier.padding(pad)) { EmptyStateBox() }
        else LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items, key = { it.id }) { ann ->
                val read = ann.readByUids.contains(uid)
                RoyalCard {
                    Text(localized(lang, ann.titleEn, ann.titleNe), fontWeight = FontWeight.Bold)
                    Text(ann.publishedAt?.toDate()?.toString() ?: "", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(6.dp))
                    Text(localized(lang, ann.bodyEn, ann.bodyNe))
                    if (!read) {
                        TextButton(onClick = { memberVm.markAnnouncementRead(ann.id) }) {
                            Text(stringResource(R.string.mark_as_read))
                        }
                    } else Text(stringResource(R.string.read_badge), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun EventsListScreen(lang: String, pastOnly: Boolean, memberVm: MemberViewModel, onBack: () -> Unit) {
    val all by memberVm.events.collectAsState()
    val filtered = all.filter { it.isPast == pastOnly }
    Scaffold(topBar = { RoyalTopBar(stringResource(if (pastOnly) R.string.past_events else R.string.upcoming_events), onBack) }) { pad ->
        if (filtered.isEmpty()) Box(Modifier.padding(pad)) { EmptyStateBox() }
        else LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(filtered, key = { it.id }) { ev ->
                RoyalCard {
                    ev.photoUrls.firstOrNull()?.let {
                        AsyncImage(model = it, contentDescription = null, modifier = Modifier.fillMaxWidth().height(160.dp), contentScale = ContentScale.Crop)
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(localized(lang, ev.titleEn, ev.titleNe), fontWeight = FontWeight.Bold)
                    Text("${ev.location} • ${ev.eventTimestamp?.toDate()?.toString() ?: ""}", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(6.dp))
                    Text(localized(lang, ev.descriptionEn, ev.descriptionNe))
                }
            }
        }
    }
}

@Composable
fun ActivitiesListScreen(lang: String, memberVm: MemberViewModel, onBack: () -> Unit) {
    val itemsList by memberVm.activities.collectAsState()
    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.club_activities), onBack) }) { pad ->
        if (itemsList.isEmpty()) Box(Modifier.padding(pad)) { EmptyStateBox() }
        else LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(itemsList, key = { it.id }) { act ->
                RoyalCard {
                    if (act.photoUrl.isNotBlank()) AsyncImage(act.photoUrl, null, Modifier.fillMaxWidth().height(150.dp), contentScale = ContentScale.Crop)
                    Text(localized(lang, act.titleEn, act.titleNe), fontWeight = FontWeight.Bold)
                    Text(localized(lang, act.summaryEn, act.summaryNe))
                }
            }
        }
    }
}

@Composable
fun CommitteeScreen(lang: String, memberVm: MemberViewModel, onBack: () -> Unit) {
    val list by memberVm.committee.collectAsState()
    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.committee), onBack) }) { pad ->
        if (list.isEmpty()) Box(Modifier.padding(pad)) { EmptyStateBox() }
        else LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list, key = { it.id }) { cm ->
                RoyalCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (cm.photoUrl.isNotBlank()) AsyncImage(cm.photoUrl, cm.name, Modifier.size(64.dp), contentScale = ContentScale.Crop)
                        Column {
                            Text(cm.name, fontWeight = FontWeight.Bold)
                            Text(localized(lang, cm.positionEn, cm.positionNe), color = DeepOrange)
                            if (cm.contactInfo.isNotBlank()) Text(cm.contactInfo, style = MaterialTheme.typography.bodySmall)
                            Text(localized(lang, cm.bioEn, cm.bioNe))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GalleryScreen(lang: String, videoOnly: Boolean, memberVm: MemberViewModel, onBack: () -> Unit) {
    val all by memberVm.gallery.collectAsState()
    val itemsList = all.filter { if (videoOnly) it.mediaType == "VIDEO" else it.mediaType == "PHOTO" }
    var playingVideoUrl by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = { RoyalTopBar(stringResource(if (videoOnly) R.string.video_gallery else R.string.photo_gallery), onBack) }) { pad ->
        if (itemsList.isEmpty()) Box(Modifier.padding(pad)) { EmptyStateBox() }
        else LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(itemsList, key = { it.id }) { item ->
                RoyalCard {
                    Text(item.albumName, style = MaterialTheme.typography.labelMedium, color = DeepOrange)
                    if (item.mediaType == "PHOTO") {
                        AsyncImage(item.mediaUrl, null, Modifier.fillMaxWidth().height(200.dp), contentScale = ContentScale.Crop)
                    } else {
                        Button(onClick = { playingVideoUrl = item.mediaUrl }) { Text(stringResource(R.string.play_video)) }
                    }
                    Text(localized(lang, item.captionEn, item.captionNe))
                }
            }
        }
    }

    playingVideoUrl?.let { url ->
        val ctx = LocalContext.current
        val exoPlayer = remember(url) {
            ExoPlayer.Builder(ctx).build().apply {
                setMediaItem(MediaItem.fromUri(url))
                prepare()
                playWhenReady = true
            }
        }
        DisposableEffect(exoPlayer) { onDispose { exoPlayer.release() } }
        AlertDialog(
            onDismissRequest = { playingVideoUrl = null },
            confirmButton = { TextButton(onClick = { playingVideoUrl = null }) { Text(stringResource(R.string.close)) } },
            text = {
                AndroidView(
                    factory = { PlayerView(it).apply { player = exoPlayer } },
                    modifier = Modifier.fillMaxWidth().height(240.dp)
                )
            }
        )
    }
}

@Composable
fun DonationScreen(lang: String, profile: MemberProfile, memberVm: MemberViewModel, onBack: () -> Unit) {
    val settings by memberVm.clubSettings.collectAsState()
    val history by memberVm.myDonations.collectAsState()
    val msg by memberVm.statusMsg.collectAsState()
    var amount by remember { mutableStateOf("") }
    var refNo by remember { mutableStateOf("") }
    var proofUri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { proofUri = it }

    LaunchedEffect(profile.uid) { memberVm.loadMyDonations(profile.uid) }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.donation_support), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                RoyalCard {
                    if (settings.donationQrUrl.isNotBlank()) {
                        AsyncImage(settings.donationQrUrl, "Club Donation QR", Modifier.fillMaxWidth().height(240.dp))
                    } else {
                        Text("Admin has not uploaded a donation QR code yet.")
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(localized(lang, settings.donationInstructionsEn, settings.donationInstructionsNe))
                    Spacer(Modifier.height(6.dp))
                    Text(stringResource(R.string.donation_notice), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
            item {
                RoyalCard {
                    OutlinedTextField(amount, { amount = it }, label = { Text(stringResource(R.string.donation_amount)) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(refNo, { refNo = it }, label = { Text(stringResource(R.string.payment_reference)) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { picker.launch("image/*") }) {
                        Text(if (proofUri == null) stringResource(R.string.upload_proof) else "Proof Selected")
                    }
                    Spacer(Modifier.height(8.dp))
                    msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                    Button(
                        onClick = {
                            memberVm.submitDonation(profile, amount, refNo, proofUri)
                            amount = ""; refNo = ""; proofUri = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.submit_donation)) }
                }
            }
            items(history, key = { it.id }) { d ->
                RoyalCard {
                    Text("${d.currency} ${d.amount} • ${d.status}", fontWeight = FontWeight.Bold)
                    Text("Ref: ${d.referenceNumber}")
                    if (d.adminNote.isNotBlank()) Text("Admin Note: ${d.adminNote}")
                }
            }
        }
    }
}

@Composable
fun FundSummaryScreen(lang: String, memberVm: MemberViewModel, onBack: () -> Unit) {
    val summary by memberVm.fundSummary.collectAsState()
    val txs by memberVm.transactions.collectAsState()
    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.fund_summary), onBack) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                RoyalCard {
                    Text("${stringResource(R.string.total_verified_donations)}: ${summary.totalVerifiedDonations}")
                    Text("${stringResource(R.string.total_income)}: ${summary.totalIncome}")
                    Text("${stringResource(R.string.total_expenses)}: ${summary.totalExpenses}")
                    Text("${stringResource(R.string.current_balance)}: ${summary.currentBalance}", fontWeight = FontWeight.Bold)
                }
            }
            if (txs.isEmpty()) item { EmptyStateBox() }
            else items(txs, key = { it.id }) { t ->
                RoyalCard {
                    Text("${t.type} (${t.category}): ${t.amount}", fontWeight = FontWeight.Bold)
                    Text(localized(lang, t.descriptionEn, t.descriptionNe))
                }
            }
        }
    }
}

@Composable
fun ClubInfoDocumentScreen(title: String, body: String, extra: String = "", onBack: () -> Unit) {
    Scaffold(topBar = { RoyalTopBar(title, onBack) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
            RoyalCard {
                Text(body.ifBlank { "Not yet published by Club Admin." })
                if (extra.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(extra)
                }
            }
        }
    }
}

@Composable
fun SettingsAndSupportScreen(
    currentLang: String,
    onChangeLanguage: (String) -> Unit,
    authVm: AuthViewModel,
    memberVm: MemberViewModel,
    onBack: () -> Unit,
    onLoggedOut: () -> Unit
) {
    val authState by authVm.state.collectAsState()
    val memMsg by memberVm.statusMsg.collectAsState()
    var curPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Scaffold(topBar = { RoyalTopBar(stringResource(R.string.settings), onBack) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            RoyalCard {
                Text(stringResource(R.string.language), fontWeight = FontWeight.Bold)
                LanguageToggleRow(currentLang, onChangeLanguage)
            }
            RoyalCard {
                Text(stringResource(R.string.change_password), fontWeight = FontWeight.Bold)
                OutlinedTextField(curPass, { curPass = it }, label = { Text(stringResource(R.string.current_password)) }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(newPass, { newPass = it }, label = { Text(stringResource(R.string.new_password)) }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Button(onClick = { authVm.changePassword(curPass, newPass) }) { Text(stringResource(R.string.update_password)) }
                authState.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                authState.infoMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            }
            RoyalCard {
                Text(stringResource(R.string.help_support), fontWeight = FontWeight.Bold)
                OutlinedTextField(subject, { subject = it }, label = { Text(stringResource(R.string.subject)) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(message, { message = it }, label = { Text(stringResource(R.string.message_to_admin)) }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Button(onClick = { memberVm.submitSupport(subject, message); subject = ""; message = "" }) {
                    Text(stringResource(R.string.submit))
                }
                memMsg?.let { Text(it) }
            }
            Button(onClick = { authVm.logout(onLoggedOut) }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error), modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.logout))
            }
        }
    }
}
