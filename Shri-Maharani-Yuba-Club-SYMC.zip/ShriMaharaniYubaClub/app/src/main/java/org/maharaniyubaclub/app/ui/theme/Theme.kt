package org.maharaniyubaclub.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val RoyalSaffron = Color(0xFFFF6F00)
val DeepOrange = Color(0xFFE65100)
val SacredGold = Color(0xFFD4AF37)
val SoftGoldBg = Color(0xFFFFF8E1)
val IvoryWhite = Color(0xFFFFFDF9)
val RoyalMaroon = Color(0xFF7B1E1E)
val DarkText = Color(0xFF2B1B12)

private val RoyalLightScheme = lightColorScheme(
    primary = RoyalSaffron,
    onPrimary = Color.White,
    primaryContainer = SoftGoldBg,
    onPrimaryContainer = RoyalMaroon,
    secondary = DeepOrange,
    onSecondary = Color.White,
    tertiary = SacredGold,
    background = IvoryWhite,
    onBackground = DarkText,
    surface = Color.White,
    onSurface = DarkText,
    error = Color(0xFFB00020)
)

@Composable
fun ShriMaharaniTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RoyalLightScheme,
        typography = Typography(
            headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, color = RoyalMaroon),
            titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
            bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp)
        ),
        content = content
    )
}
