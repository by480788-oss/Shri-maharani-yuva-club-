package org.maharaniyubaclub.app.data.model

import com.google.firebase.Timestamp

data class CountryCodeOption(val name: String, val dialCode: String, val flag: String)

val SUPPORTED_COUNTRIES = listOf(
    CountryCodeOption("Nepal", "+977", "🇳🇵"),
    CountryCodeOption("Qatar", "+974", "🇶🇦"),
    CountryCodeOption("Saudi Arabia", "+966", "🇸🇦"),
    CountryCodeOption("UAE", "+971", "🇦🇪"),
    CountryCodeOption("India", "+91", "🇮🇳"),
    CountryCodeOption("Kuwait", "+965", "🇰🇼"),
    CountryCodeOption("Malaysia", "+60", "🇲🇾"),
    CountryCodeOption("United Kingdom", "+44", "🇬🇧"),
    CountryCodeOption("United States", "+1", "🇺🇸")
)

data class MemberProfile(
    val uid: String = "",
    val memberCode: String = "",
    val fullName: String = "",
    val email: String = "",
    val phoneE164: String = "",
    val countryCode: String = "+977",
    val approvalStatus: String = "PENDING",
    val activeStatus: String = "INACTIVE",
    val photoUrl: String = "",
    val address: String = "",
    val privacyShowPhone: Boolean = false,
    val privacyShowEmail: Boolean = false,
    val joinedAt: Timestamp? = null
)

data class AdminRecord(
    val uid: String = "",
    val email: String = "",
    val fullName: String = "",
    val role: String = "ADMIN",
    val active: Boolean = true
)

data class AnnouncementItem(
    val id: String = "",
    val type: String = "ANNOUNCEMENT",
    val titleEn: String = "",
    val titleNe: String = "",
    val bodyEn: String = "",
    val bodyNe: String = "",
    val publishedAt: Timestamp? = null,
    val readByUids: List<String> = emptyList()
)

data class ClubEvent(
    val id: String = "",
    val titleEn: String = "",
    val titleNe: String = "",
    val descriptionEn: String = "",
    val descriptionNe: String = "",
    val location: String = "",
    val eventTimestamp: Timestamp? = null,
    val photoUrls: List<String> = emptyList(),
    val isPast: Boolean = false
)

data class ClubActivity(
    val id: String = "",
    val titleEn: String = "",
    val titleNe: String = "",
    val summaryEn: String = "",
    val summaryNe: String = "",
    val activityDate: Timestamp? = null,
    val photoUrl: String = ""
)

data class CommitteeMember(
    val id: String = "",
    val name: String = "",
    val positionEn: String = "",
    val positionNe: String = "",
    val photoUrl: String = "",
    val contactInfo: String = "",
    val bioEn: String = "",
    val bioNe: String = "",
    val orderIndex: Int = 0
)

data class GalleryItem(
    val id: String = "",
    val albumName: String = "",
    val mediaType: String = "PHOTO",
    val mediaUrl: String = "",
    val captionEn: String = "",
    val captionNe: String = "",
    val uploadedAt: Timestamp? = null
)

data class DonationRecord(
    val id: String = "",
    val memberUid: String = "",
    val memberName: String = "",
    val memberCode: String = "",
    val amount: Double = 0.0,
    val currency: String = "NPR",
    val referenceNumber: String = "",
    val proofUrl: String = "",
    val status: String = "PENDING",
    val adminNote: String = "",
    val submittedAt: Timestamp? = null
)

data class FundTransaction(
    val id: String = "",
    val type: String = "INCOME",
    val category: String = "",
    val amount: Double = 0.0,
    val descriptionEn: String = "",
    val descriptionNe: String = "",
    val linkedDonationId: String = "",
    val recordedByUid: String = "",
    val transactionDate: Timestamp? = null
)

data class ClubSettings(
    val officialLogoUrl: String = "",
    val donationQrUrl: String = "",
    val donationInstructionsEn: String = "",
    val donationInstructionsNe: String = "",
    val aboutEn: String = "",
    val aboutNe: String = "",
    val objectivesEn: String = "",
    val objectivesNe: String = "",
    val missionVisionEn: String = "",
    val missionVisionNe: String = "",
    val contactEmail: String = "",
    val contactPhone: String = "",
    val contactAddress: String = "",
    val socialLinks: String = "",
    val termsEn: String = "",
    val termsNe: String = "",
    val privacyEn: String = "",
    val privacyNe: String = ""
)

data class NotificationRecord(
    val id: String = "",
    val titleEn: String = "",
    val titleNe: String = "",
    val bodyEn: String = "",
    val bodyNe: String = "",
    val status: String = "",
    val sentCount: Int = 0,
    val failureCount: Int = 0,
    val createdAt: Timestamp? = null
)

data class AdminActivityLog(
    val id: String = "",
    val adminUid: String = "",
    val adminEmail: String = "",
    val action: String = "",
    val targetCollection: String = "",
    val targetId: String = "",
    val details: String = "",
    val timestamp: Timestamp? = null
)

data class FundSummary(
    val totalVerifiedDonations: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpenses: Double = 0.0
) {
    val currentBalance: Double get() = totalIncome - totalExpenses
}

data class UserSession(
    val uid: String = "",
    val isAdmin: Boolean = false,
    val isSuperAdmin: Boolean = false,
    val memberProfile: MemberProfile? = null
)
