package org.maharaniyubaclub.app.data.repository

import android.app.Activity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.tasks.await
import org.maharaniyubaclub.app.FirestoreProvider
import org.maharaniyubaclub.app.data.model.MemberProfile
import org.maharaniyubaclub.app.data.model.UserSession
import java.util.concurrent.TimeUnit

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirestoreProvider.db,
    private val functions: FirebaseFunctions = FirebaseFunctions.getInstance()
) {
    fun currentUid(): String? = auth.currentUser?.uid

    suspend fun checkDuplicates(email: String, phoneE164: String): Pair<Boolean, Boolean> {
        val result = functions.getHttpsCallable("checkDuplicateRegistration")
            .call(mapOf("email" to email.trim().lowercase(), "phoneE164" to phoneE164.trim()))
            .await()
        val data = result.data as Map<*, *>
        return (data["emailExists"] as? Boolean ?: false) to (data["phoneExists"] as? Boolean ?: false)
    }

    fun sendSmsOtp(
        activity: Activity,
        phoneE164: String,
        onCodeSent: (String) -> Unit,
        onAutoVerified: (PhoneAuthCredential) -> Unit,
        onFailed: (String) -> Unit
    ) {
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneE164)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    onAutoVerified(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    onFailed(e.localizedMessage ?: "SMS verification failed.")
                }

                override fun onCodeSent(verificationId: String, token: PhoneAuthProvider.ForceResendingToken) {
                    onCodeSent(verificationId)
                }
            })
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    suspend fun sendEmailOtp(email: String, purpose: String) {
        functions.getHttpsCallable("sendEmailOtp")
            .call(mapOf("email" to email.trim().lowercase(), "purpose" to purpose))
            .await()
    }

    suspend fun verifyEmailOtp(email: String, code: String, purpose: String): Boolean {
        val res = functions.getHttpsCallable("verifyEmailOtp")
            .call(mapOf("email" to email.trim().lowercase(), "code" to code.trim(), "purpose" to purpose))
            .await()
        val data = res.data as Map<*, *>
        return data["verified"] as? Boolean ?: false
    }

    suspend fun completeRegistration(
        fullName: String,
        email: String,
        password: String,
        phoneE164: String,
        countryCode: String,
        phoneCredential: PhoneAuthCredential,
        preferredLanguage: String
    ) {
        val authResult = auth.createUserWithEmailAndPassword(email.trim().lowercase(), password).await()
        val user = authResult.user ?: error("User creation failed.")
        try {
            user.linkWithCredential(phoneCredential).await()
            user.sendEmailVerification().await()
            functions.getHttpsCallable("registerMember").call(
                mapOf(
                    "fullName" to fullName.trim(),
                    "email" to email.trim().lowercase(),
                    "phoneE164" to phoneE164.trim(),
                    "countryCode" to countryCode,
                    "preferredLanguage" to preferredLanguage
                )
            ).await()
            syncFcmToken()
        } catch (e: Exception) {
            user.delete().await()
            throw e
        }
    }

    suspend fun signInWithEmail(email: String, password: String) {
        auth.signInWithEmailAndPassword(email.trim().lowercase(), password).await()
        syncFcmToken()
    }

    suspend fun signInWithPhoneAndPassword(phoneE164: String, password: String) {
        val res = functions.getHttpsCallable("signInWithPhonePassword")
            .call(mapOf("phoneE164" to phoneE164.trim(), "password" to password))
            .await()
        val token = (res.data as Map<*, *>)["customToken"] as String
        auth.signInWithCustomToken(token).await()
        syncFcmToken()
    }

    suspend fun signInWithPhoneCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential).await()
        syncFcmToken()
    }

    suspend fun sendPasswordResetEmail(email: String) {
        auth.sendPasswordResetEmail(email.trim().lowercase()).await()
    }

    suspend fun resetPasswordWithEmailOtp(email: String, newPassword: String) {
        functions.getHttpsCallable("resetPasswordWithEmailOtp")
            .call(mapOf("email" to email.trim().lowercase(), "newPassword" to newPassword))
            .await()
    }

    suspend fun changePassword(currentPassword: String, newPassword: String) {
        val user = auth.currentUser ?: error("Not signed in.")
        val email = user.email ?: error("Email required for re-authentication.")
        user.reauthenticate(EmailAuthProvider.getCredential(email, currentPassword)).await()
        user.updatePassword(newPassword).await()
    }

    suspend fun loadCurrentSession(): UserSession? {
        val user = auth.currentUser ?: return null
        val tokenResult = user.getIdToken(true).await()
        val claims = tokenResult.claims
        var isAdmin = claims["admin"] as? Boolean ?: false
        var isSuperAdmin = claims["superAdmin"] as? Boolean ?: false

        // Fallback verification against admins registry document if custom claims are still propagating
        if (!isAdmin && !isSuperAdmin) {
            try {
                val adminSnap = db.collection("admins").document(user.uid).get().await()
                if (adminSnap.exists() && adminSnap.getBoolean("active") == true) {
                    val role = adminSnap.getString("role")
                    isAdmin = true
                    isSuperAdmin = role == "SUPER_ADMIN"
                }
            } catch (_: Exception) {
            }
        }

        val memberSnap = try {
            db.collection("members").document(user.uid).get().await()
        } catch (_: Exception) {
            null
        }
        val profile = memberSnap?.toObject(MemberProfile::class.java)
        return UserSession(uid = user.uid, isAdmin = isAdmin, isSuperAdmin = isSuperAdmin, memberProfile = profile)
    }

    suspend fun syncFcmToken() {
        val uid = auth.currentUser?.uid ?: return
        try {
            val token = FirebaseMessaging.getInstance().token.await()
            db.collection("users").document(uid).update("fcmToken", token).await()
        } catch (_: Exception) {
        }
    }

    fun logout() {
        auth.signOut()
    }
}
