package org.maharaniyubaclub.app.ui.screens.auth

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import org.maharaniyubaclub.app.R
import org.maharaniyubaclub.app.ui.components.ClubEmblem
import org.maharaniyubaclub.app.ui.theme.*

@Composable
fun SplashScreen(
    logoUrl: String,
    sessionChecked: Boolean,
    isLoggedIn: Boolean,
    isAdmin: Boolean,
    onNavigatePublic: () -> Unit,
    onNavigateMember: () -> Unit,
    onNavigateAdmin: () -> Unit
) {
    var visible by remember { mutableStateOf(false) }
    val alpha by animateFloatAsState(if (visible) 1f else 0f, label = "splash")

    LaunchedEffect(sessionChecked) {
        visible = true
        if (sessionChecked) {
            delay(1200)
            when {
                isLoggedIn && isAdmin -> onNavigateAdmin()
                isLoggedIn -> onNavigateMember()
                else -> onNavigatePublic()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepOrange, RoyalSaffron, SacredGold))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.alpha(alpha).padding(24.dp)) {
            ClubEmblem(logoUrl, 120)
            Spacer(Modifier.height(20.dp))
            Text(stringResource(R.string.app_name), color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.club_name_devanagari), color = SoftGoldBg, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.royal_motto), color = Color.White.copy(alpha = 0.9f))
            Spacer(Modifier.height(24.dp))
            CircularProgressIndicator(color = Color.White)
        }
    }
}
