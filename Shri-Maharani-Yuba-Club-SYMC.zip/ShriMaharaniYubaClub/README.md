# Shri Maharani Yuba Club (श्री महारानी युवा क्लब) — Native Android Studio Project

## 1. Provisioned Firebase Project Details
- **Firebase Project ID**: `gen-lang-client-0737154464`
- **Firestore Database ID**: `ai-studio-ec908cc0-c6c4-4d09-b597-55214b1cbe7f` (configured in `app/build.gradle.kts` and `firebase/functions/index.js`)
- **Android Application ID**: `org.maharaniyubaclub.app`
- **Firestore Rules**: Hardened rules have been deployed to this project (`firestore.rules`).

## 2. Required External Setup Before Building & Testing APK
1. **Register Android App in Firebase Console & Download `google-services.json`**:
   - Open Firebase Console for project `gen-lang-client-0737154464`.
   - Add an Android app with package name `org.maharaniyubaclub.app`.
   - Add your Debug and Release **SHA-1** and **SHA-256** fingerprints (required for Firebase Phone Auth / SMS OTP).
   - Download `google-services.json` and place it at `ShriMaharaniYubaClub/app/google-services.json`.
2. **Enable Authentication Providers**:
   - In *Authentication → Sign-in method*, enable **Email/Password** and **Phone**.
   - Ensure Firebase Blaze billing plan is active for international SMS quotas (`+977` Nepal, `+974` Qatar, `+966` Saudi Arabia, etc.) and Cloud Functions outbound network calls.
3. **Deploy Cloud Functions, Storage Rules & Secrets**:
   ```bash
   cd firebase/functions && npm install && cd ..
   firebase use gen-lang-client-0737154464
   firebase functions:secrets:set SMTP_HOST
   firebase functions:secrets:set SMTP_PORT
   firebase functions:secrets:set SMTP_USER
   firebase functions:secrets:set SMTP_PASS
   firebase functions:secrets:set SMTP_FROM
   firebase functions:secrets:set FIREBASE_WEB_API_KEY
   firebase functions:secrets:set SUPER_ADMIN_BOOTSTRAP_KEY
   firebase deploy --only functions,storage
   ```
4. **Initialize the First Super Admin (One-Time)**:
   - Create the Super Admin account in Firebase Auth (Email/Password).
   - Sign in as that user in the app or via a temporary script calling `bootstrapSuperAdmin({ bootstrapKey })`, OR grant `{ admin: true, superAdmin: true }` custom claims + create `/admins/{uid}` with `role: "SUPER_ADMIN"` using Firebase Admin SDK.

## 3. Build Debug & Signed Release APK
Open `ShriMaharaniYubaClub/` in **Android Studio**, sync Gradle, or run from terminal:

- **Debug APK**:
  ```bash
  ./gradlew assembleDebug
  # Output: app/build/outputs/apk/debug/app-debug.apk
  ```
- **Signed Release APK**:
  1. Generate a release keystore:
     ```bash
     keytool -genkeypair -v -keystore release-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias maharani_release
     ```
  2. Add signingConfig in `app/build.gradle.kts` or use Android Studio *Build → Generate Signed Bundle / APK → APK*.
  3. Run:
     ```bash
     ./gradlew assembleRelease
     # Output: app/build/outputs/apk/release/app-release.apk
     ```
