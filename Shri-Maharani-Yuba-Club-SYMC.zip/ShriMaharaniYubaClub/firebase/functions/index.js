const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const { getFirestore } = require("firebase-admin/firestore");
const crypto = require("crypto");
const nodemailer = require("nodemailer");

admin.initializeApp();

// Matches the provisioned AI Studio Firestore database ID; change to "(default)" if using default database.
const FIRESTORE_DATABASE_ID =
  process.env.FIRESTORE_DATABASE_ID || "ai-studio-ec908cc0-c6c4-4d09-b597-55214b1cbe7f";
const db =
  FIRESTORE_DATABASE_ID === "(default)"
    ? getFirestore()
    : getFirestore(FIRESTORE_DATABASE_ID);

const SMTP_HOST = defineSecret("SMTP_HOST");
const SMTP_PORT = defineSecret("SMTP_PORT");
const SMTP_USER = defineSecret("SMTP_USER");
const SMTP_PASS = defineSecret("SMTP_PASS");
const SMTP_FROM = defineSecret("SMTP_FROM");
const FIREBASE_WEB_API_KEY = defineSecret("FIREBASE_WEB_API_KEY");
const SUPER_ADMIN_BOOTSTRAP_KEY = defineSecret("SUPER_ADMIN_BOOTSTRAP_KEY");

function assertAdmin(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication required.");
  const token = request.auth.token;
  if (!token.admin && !token.superAdmin) {
    throw new HttpsError("permission-denied", "Admin privileges required.");
  }
}

function assertSuperAdmin(request) {
  if (!request.auth || !request.auth.token.superAdmin) {
    throw new HttpsError("permission-denied", "Super Admin privileges required.");
  }
}

async function writeAuditLog(adminUid, adminEmail, action, targetCollection, targetId, details) {
  await db.collection("admin_activity_logs").add({
    adminUid,
    adminEmail: adminEmail || "",
    action,
    targetCollection,
    targetId,
    details,
    timestamp: admin.firestore.FieldValue.serverTimestamp(),
  });
}

// 1. Pre-registration duplicate check (returns booleans only, no PII leaked)
exports.checkDuplicateRegistration = onCall(async (request) => {
  const email = (request.data.email || "").trim().toLowerCase();
  const phoneE164 = (request.data.phoneE164 || "").trim();
  if (!email || !phoneE164) {
    throw new HttpsError("invalid-argument", "Email and mobile number are required.");
  }
  const emailSnap = await db.collection("members").where("email", "==", email).limit(1).get();
  const phoneSnap = await db.collection("members").where("phoneE164", "==", phoneE164).limit(1).get();
  return {
    emailExists: !emailSnap.empty,
    phoneExists: !phoneSnap.empty,
  };
});

// 2. Real Email OTP via configured SMTP provider (never generates fake OTPs)
exports.sendEmailOtp = onCall(
  { secrets: [SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM] },
  async (request) => {
    const email = (request.data.email || "").trim().toLowerCase();
    const purpose = (request.data.purpose || "REGISTRATION").trim();
    if (!email || !email.includes("@")) {
      throw new HttpsError("invalid-argument", "Valid email is required.");
    }
    if (!SMTP_HOST.value() || !SMTP_USER.value() || !SMTP_PASS.value()) {
      throw new HttpsError(
        "failed-precondition",
        "Email delivery provider is not configured. Set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM secrets on Firebase Functions."
      );
    }

    const otp = crypto.randomInt(100000, 999999).toString();
    const salt = crypto.randomBytes(16).toString("hex");
    const otpHash = crypto.createHash("sha256").update(`${otp}:${salt}`).digest("hex");
    const docId = crypto.createHash("sha256").update(`${email}:${purpose}`).digest("hex");

    await db.collection("email_otps").doc(docId).set({
      email,
      purpose,
      otpHash,
      salt,
      attempts: 0,
      verified: false,
      expiresAt: Date.now() + 10 * 60 * 1000,
    });

    const transporter = nodemailer.createTransport({
      host: SMTP_HOST.value(),
      port: Number(SMTP_PORT.value() || "587"),
      secure: Number(SMTP_PORT.value()) === 465,
      auth: { user: SMTP_USER.value(), pass: SMTP_PASS.value() },
    });

    await transporter.sendMail({
      from: SMTP_FROM.value() || SMTP_USER.value(),
      to: email,
      subject: "Shri Maharani Yuba Club - Verification OTP",
      text: `Your verification OTP is ${otp}. It expires in 10 minutes. Do not share this code.`,
    });

    return { sent: true };
  }
);

// 3. Verify Email OTP server-side
exports.verifyEmailOtp = onCall(async (request) => {
  const email = (request.data.email || "").trim().toLowerCase();
  const code = (request.data.code || "").trim();
  const purpose = (request.data.purpose || "REGISTRATION").trim();
  const docId = crypto.createHash("sha256").update(`${email}:${purpose}`).digest("hex");
  const ref = db.collection("email_otps").doc(docId);
  const snap = await ref.get();

  if (!snap.exists) throw new HttpsError("not-found", "No active OTP request found.");
  const data = snap.data();
  if (Date.now() > data.expiresAt) throw new HttpsError("deadline-exceeded", "OTP expired.");
  if (data.attempts >= 5) throw new HttpsError("resource-exhausted", "Too many failed attempts.");

  const candidateHash = crypto.createHash("sha256").update(`${code}:${data.salt}`).digest("hex");
  if (candidateHash !== data.otpHash) {
    await ref.update({ attempts: admin.firestore.FieldValue.increment(1) });
    throw new HttpsError("invalid-argument", "Invalid OTP code.");
  }

  await ref.update({ verified: true });
  return { verified: true };
});

// 4. Register Member only after verifying Firebase Auth phone + email OTP
exports.registerMember = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign-in required.");
  const uid = request.auth.uid;
  const fullName = (request.data.fullName || "").trim();
  const email = (request.data.email || "").trim().toLowerCase();
  const phoneE164 = (request.data.phoneE164 || "").trim();
  const countryCode = (request.data.countryCode || "").trim();
  const preferredLanguage = request.data.preferredLanguage === "ne" ? "ne" : "en";

  const userRecord = await admin.auth().getUser(uid);
  if (!userRecord.phoneNumber || userRecord.phoneNumber !== phoneE164) {
    throw new HttpsError("failed-precondition", "Verified mobile number mismatch.");
  }

  const otpDocId = crypto.createHash("sha256").update(`${email}:REGISTRATION`).digest("hex");
  const otpSnap = await db.collection("email_otps").doc(otpDocId).get();
  if (!otpSnap.exists || !otpSnap.data().verified) {
    throw new HttpsError("failed-precondition", "Email OTP verification is required.");
  }

  const existingEmail = await db.collection("members").where("email", "==", email).limit(1).get();
  const existingPhone = await db.collection("members").where("phoneE164", "==", phoneE164).limit(1).get();
  if (!existingEmail.empty || !existingPhone.empty) {
    throw new HttpsError("already-exists", "An account with this email or mobile already exists.");
  }

  const now = admin.firestore.FieldValue.serverTimestamp();
  await db.collection("users").doc(uid).set({
    uid,
    fullName,
    email,
    phoneE164,
    preferredLanguage,
    emailOtpVerified: true,
    phoneVerified: true,
    createdAt: now,
  });

  await db.collection("members").doc(uid).set({
    uid,
    memberCode: "",
    fullName,
    email,
    phoneE164,
    countryCode,
    approvalStatus: "PENDING",
    activeStatus: "INACTIVE",
    photoUrl: "",
    address: "",
    privacyShowPhone: false,
    privacyShowEmail: false,
    joinedAt: now,
    updatedAt: now,
  });

  await db.collection("email_otps").doc(otpDocId).delete();
  return { registered: true, approvalStatus: "PENDING" };
});

// 5. Secure Mobile + Password Sign-In without leaking email addresses
exports.signInWithPhonePassword = onCall(
  { secrets: [FIREBASE_WEB_API_KEY] },
  async (request) => {
    const phoneE164 = (request.data.phoneE164 || "").trim();
    const password = request.data.password || "";
    if (!phoneE164 || !password) {
      throw new HttpsError("invalid-argument", "Mobile number and password are required.");
    }
    if (!FIREBASE_WEB_API_KEY.value()) {
      throw new HttpsError("failed-precondition", "FIREBASE_WEB_API_KEY secret is not configured.");
    }

    let userRecord;
    try {
      userRecord = await admin.auth().getUserByPhoneNumber(phoneE164);
    } catch {
      throw new HttpsError("not-found", "Invalid mobile number or password.");
    }
    if (!userRecord.email) {
      throw new HttpsError("failed-precondition", "Account has no linked email.");
    }

    const resp = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${FIREBASE_WEB_API_KEY.value()}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: userRecord.email,
          password,
          returnSecureToken: false,
        }),
      }
    );
    if (!resp.ok) {
      throw new HttpsError("unauthenticated", "Invalid mobile number or password.");
    }
    const customToken = await admin.auth().createCustomToken(userRecord.uid);
    return { customToken };
  }
);

// 6. Reset Password after verified Email OTP
exports.resetPasswordWithEmailOtp = onCall(async (request) => {
  const email = (request.data.email || "").trim().toLowerCase();
  const newPassword = request.data.newPassword || "";
  if (newPassword.length < 8) {
    throw new HttpsError("invalid-argument", "Password must be at least 8 characters.");
  }
  const otpDocId = crypto.createHash("sha256").update(`${email}:RESET`).digest("hex");
  const otpSnap = await db.collection("email_otps").doc(otpDocId).get();
  if (!otpSnap.exists || !otpSnap.data().verified) {
    throw new HttpsError("failed-precondition", "Email OTP must be verified first.");
  }
  const userRecord = await admin.auth().getUserByEmail(email);
  await admin.auth().updateUser(userRecord.uid, { password: newPassword });
  await db.collection("email_otps").doc(otpDocId).delete();
  return { reset: true };
});

// 7. One-time Super Admin Bootstrap
exports.bootstrapSuperAdmin = onCall(
  { secrets: [SUPER_ADMIN_BOOTSTRAP_KEY] },
  async (request) => {
    if (!request.auth) throw new HttpsError("unauthenticated", "Sign in first.");
    const key = request.data.bootstrapKey || "";
    if (!SUPER_ADMIN_BOOTSTRAP_KEY.value() || key !== SUPER_ADMIN_BOOTSTRAP_KEY.value()) {
      throw new HttpsError("permission-denied", "Invalid bootstrap key.");
    }
    const existingSuper = await db.collection("admins").where("role", "==", "SUPER_ADMIN").limit(1).get();
    if (!existingSuper.empty) {
      throw new HttpsError("already-exists", "A Super Admin already exists.");
    }
    const uid = request.auth.uid;
    const user = await admin.auth().getUser(uid);
    await admin.auth().setCustomUserClaims(uid, { admin: true, superAdmin: true });
    await db.collection("admins").doc(uid).set({
      uid,
      email: user.email || "",
      fullName: user.displayName || "Super Admin",
      role: "SUPER_ADMIN",
      active: true,
      grantedByUid: uid,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
    await writeAuditLog(uid, user.email, "BOOTSTRAP_SUPER_ADMIN", "admins", uid, "Initialized Super Admin");
    return { initialized: true };
  }
);

// 8. Super Admin authorizes or revokes Admins
exports.setAdminRole = onCall(async (request) => {
  assertSuperAdmin(request);
  const targetEmail = (request.data.email || "").trim().toLowerCase();
  const grant = Boolean(request.data.grant);
  const user = await admin.auth().getUserByEmail(targetEmail);
  if (user.uid === request.auth.uid && !grant) {
    throw new HttpsError("failed-precondition", "Super Admin cannot revoke own role.");
  }

  await admin.auth().setCustomUserClaims(user.uid, { admin: grant, superAdmin: false });
  if (grant) {
    await db.collection("admins").doc(user.uid).set({
      uid: user.uid,
      email: user.email || targetEmail,
      fullName: user.displayName || targetEmail,
      role: "ADMIN",
      active: true,
      grantedByUid: request.auth.uid,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  } else {
    await db.collection("admins").doc(user.uid).delete();
  }
  await writeAuditLog(
    request.auth.uid,
    request.auth.token.email,
    grant ? "GRANT_ADMIN" : "REVOKE_ADMIN",
    "admins",
    user.uid,
    `Target: ${targetEmail}`
  );
  return { updated: true };
});

// 9. Admin approves/rejects member & assigns unique Member ID
exports.adminUpdateMemberStatus = onCall(async (request) => {
  assertAdmin(request);
  const memberUid = request.data.memberUid;
  const approvalStatus = request.data.approvalStatus;
  const activeStatus = request.data.activeStatus;

  const memberRef = db.collection("members").doc(memberUid);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(memberRef);
    if (!snap.exists) throw new HttpsError("not-found", "Member not found.");
    let memberCode = snap.data().memberCode || "";
    if (approvalStatus === "APPROVED" && !memberCode) {
      const counterRef = db.collection("club_settings").doc("counters");
      const counterSnap = await tx.get(counterRef);
      const nextNum = ((counterSnap.exists && counterSnap.data().memberSeq) || 0) + 1;
      tx.set(counterRef, { memberSeq: nextNum }, { merge: true });
      const year = new Date().getFullYear();
      memberCode = `SMYC-${year}-${String(nextNum).padStart(4, "0")}`;
    }
    tx.update(memberRef, {
      approvalStatus,
      activeStatus,
      memberCode,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  });

  await writeAuditLog(
    request.auth.uid,
    request.auth.token.email,
    "UPDATE_MEMBER_STATUS",
    "members",
    memberUid,
    `approval=${approvalStatus}, active=${activeStatus}`
  );
  return { updated: true };
});

// 10. Admin manually verifies/rejects donation -> atomically creates fund_transactions entry
exports.adminVerifyDonation = onCall(async (request) => {
  assertAdmin(request);
  const donationId = request.data.donationId;
  const decision = request.data.decision;
  const adminNote = (request.data.adminNote || "").trim();

  if (decision !== "VERIFIED" && decision !== "REJECTED") {
    throw new HttpsError("invalid-argument", "Invalid decision.");
  }

  const donRef = db.collection("donations").doc(donationId);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(donRef);
    if (!snap.exists) throw new HttpsError("not-found", "Donation record not found.");
    const data = snap.data();
    if (data.status !== "PENDING") {
      throw new HttpsError("failed-precondition", "Donation already processed.");
    }

    tx.update(donRef, {
      status: decision,
      adminNote,
      verifiedAt: admin.firestore.FieldValue.serverTimestamp(),
      verifiedByUid: request.auth.uid,
    });

    if (decision === "VERIFIED") {
      const txRef = db.collection("fund_transactions").doc();
      tx.set(txRef, {
        id: txRef.id,
        type: "INCOME",
        category: "DONATION",
        amount: data.amount,
        descriptionEn: `Verified donation from ${data.memberName} (Ref: ${data.referenceNumber})`,
        descriptionNe: `${data.memberName} बाट प्रमाणित दान (सन्दर्भ: ${data.referenceNumber})`,
        linkedDonationId: donationId,
        recordedByUid: request.auth.uid,
        transactionDate: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
  });

  await writeAuditLog(
    request.auth.uid,
    request.auth.token.email,
    `DONATION_${decision}`,
    "donations",
    donationId,
    adminNote
  );
  return { processed: true };
});

// 11. Admin creates member directly
exports.adminCreateMember = onCall(async (request) => {
  assertAdmin(request);
  const fullName = (request.data.fullName || "").trim();
  const email = (request.data.email || "").trim().toLowerCase();
  const phoneE164 = (request.data.phoneE164 || "").trim();
  const countryCode = (request.data.countryCode || "+977").trim();
  const tempPassword = request.data.password || crypto.randomBytes(12).toString("hex");

  const user = await admin.auth().createUser({
    email,
    phoneNumber: phoneE164,
    password: tempPassword,
    displayName: fullName,
  });

  const counterRef = db.collection("club_settings").doc("counters");
  const memberCode = await db.runTransaction(async (tx) => {
    const cSnap = await tx.get(counterRef);
    const nextNum = ((cSnap.exists && cSnap.data().memberSeq) || 0) + 1;
    tx.set(counterRef, { memberSeq: nextNum }, { merge: true });
    return `SMYC-${new Date().getFullYear()}-${String(nextNum).padStart(4, "0")}`;
  });

  const now = admin.firestore.FieldValue.serverTimestamp();
  await db.collection("users").doc(user.uid).set({
    uid: user.uid,
    fullName,
    email,
    phoneE164,
    preferredLanguage: "en",
    emailOtpVerified: false,
    phoneVerified: false,
    createdAt: now,
  });
  await db.collection("members").doc(user.uid).set({
    uid: user.uid,
    memberCode,
    fullName,
    email,
    phoneE164,
    countryCode,
    approvalStatus: "APPROVED",
    activeStatus: "ACTIVE",
    photoUrl: "",
    address: "",
    privacyShowPhone: false,
    privacyShowEmail: false,
    joinedAt: now,
    updatedAt: now,
  });

  await writeAuditLog(request.auth.uid, request.auth.token.email, "ADMIN_CREATE_MEMBER", "members", user.uid, email);
  return { uid: user.uid, memberCode };
});

// 12. Publish announcement + honest FCM notification dispatch
exports.publishAnnouncementAndNotify = onCall(async (request) => {
  assertAdmin(request);
  const { type, titleEn, titleNe, bodyEn, bodyNe, sendPush } = request.data;
  const annRef = db.collection("announcements").doc();
  await annRef.set({
    id: annRef.id,
    type: type || "ANNOUNCEMENT",
    titleEn,
    titleNe,
    bodyEn,
    bodyNe,
    publishedAt: admin.firestore.FieldValue.serverTimestamp(),
    readByUids: [],
  });

  let sentCount = 0;
  let failureCount = 0;
  let status = "NOT_REQUESTED";

  if (sendPush) {
    const usersSnap = await db.collection("users").where("fcmToken", "!=", "").get();
    const tokens = usersSnap.docs.map((d) => d.data().fcmToken).filter(Boolean);
    if (tokens.length === 0) {
      status = "NO_REGISTERED_DEVICES";
    } else {
      const response = await admin.messaging().sendEachForMulticast({
        tokens,
        notification: { title: titleEn, body: bodyEn },
        data: { announcementId: annRef.id, titleNe: titleNe || "", bodyNe: bodyNe || "" },
      });
      sentCount = response.successCount;
      failureCount = response.failureCount;
      status = response.failureCount === 0 ? "DELIVERED" : response.successCount > 0 ? "PARTIAL" : "FAILED";
    }
  }

  await db.collection("notification_records").add({
    titleEn,
    titleNe,
    bodyEn,
    bodyNe,
    status,
    sentCount,
    failureCount,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    createdByUid: request.auth.uid,
  });
  await writeAuditLog(request.auth.uid, request.auth.token.email, "PUBLISH_ANNOUNCEMENT", "announcements", annRef.id, `FCM=${status}`);
  return { id: annRef.id, status, sentCount, failureCount };
});
